import 'package:flutter/material.dart';

import 'modules/main/mainpage.dart';

void main() => runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'WW:IT',
    initialRoute: '/main',
    routes: {"/main": (context) => MainPage()}));
