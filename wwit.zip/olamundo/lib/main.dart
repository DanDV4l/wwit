//inicialização

import 'package:flutter/material.dart';
import 'package:olamundo/modules/formpage/formpage.dart';
import 'modules/main/mainpage.dart';

void main() => runApp(MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'WW:IT',
        initialRoute: '/',
        routes: {
          "/": (context) =>
              MainPage(), //frame principal - barra superior / inferior
          "/request": (context) => FormPage() //formulário solicitar serviço
        }));
