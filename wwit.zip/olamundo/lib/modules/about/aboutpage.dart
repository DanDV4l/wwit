import 'package:flutter/material.dart';
import 'package:olamundo/shared/apptexts.dart';
import 'package:olamundo/shared/objects/aboutbox.dart';
import 'package:olamundo/shared/objects/buttons.dart';
import 'package:olamundo/shared/objects/logo.dart';

import 'package:olamundo/shared/themes/appimages.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
        child: Container(
      margin: EdgeInsets.all(15),
      width: MediaQuery.of(context).size.width,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            child: Column(children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Column(
                    children: [
                      buildAboutBox(
                        context,
                        title: AboutTexts.title1,
                        text: AboutTexts.text1,
                      ),
                    ],
                  ),
                  VerticalDivider(),
                  Column(
                    children: [
                      buildLogoLarge(),
                      Container(
                        margin: EdgeInsets.all(25),
                        width: 200,
                        height: 1,
                        color: Colors.white,
                      ),
                      Text(
                        "TECNOLOGIAS",
                        style: Styles.textTitleBox,
                      ),
                      Wrap(
                        children: [
                          buildButton(
                              image: AppImages.flutter,
                              label: "FLUTTER",
                              onTap: null),
                          buildButton(
                              image: AppImages.firebase,
                              label: "FIREBASE",
                              onTap: null),
                          buildButton(
                              image: AppImages.api,
                              label: "RESTFUL API",
                              onTap: null),
                        ],
                      ),
                    ],
                  )
                ],
              )

              //buildAboutTextBox(context)],
            ]),
          ),
        ],
      ),
    ));
  }
}
