import 'package:flutter/material.dart';
import 'package:olamundo/shared/apptexts.dart';
import 'package:olamundo/shared/objects/buttons.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/themes/appimages.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';
// ignore: avoid_web_libraries_in_flutter
import 'dart:html' as html;

class AboutPageMobile extends StatelessWidget {
  const AboutPageMobile({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        child: Container(
          margin: EdgeInsets.all(15),
          width: MediaQuery.of(context).size.width,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              buildLogoLarge(),
              Container(
                margin: EdgeInsets.all(25),
                width: 200,
                height: 1,
                color: Colors.white,
              ),
              Text(
                AboutTexts.title1,
                style: Styles.textTitle,
              ),
              Container(
                  width: MediaQuery.of(context).size.width * 0.8,
                  child: Text(AboutTexts.text1, style: Styles.appText)),
              Container(
                margin: EdgeInsets.only(top: 25, bottom: 45),
                width: 200,
                height: 1,
                color: Colors.white,
              ),

              Wrap(
                children: [
                  buildIconButton(
                      icon: AppImages.whatsapp,
                      label: "WhatsApp",
                      onTap: () {
                        html.window.open('https://wa.me/5535988641641', '');
                      }),
                  buildIconButton(
                      icon: AppImages.linkedin,
                      label: "LinkedIn",
                      onTap: () {
                        html.window.open(
                            'https://www.linkedin.com/in/daniel-souza-pinto-40b0b4212',
                            '');
                      }),
                  buildIconButton(
                      icon: AppImages.github,
                      label: "Github",
                      onTap: () {
                        html.window.open('https://github.com/DanDV4l', '');
                      }),
                ],
              ),

              //buildAboutTextBox(context)],
            ],
          ),
        ));
  }
}
