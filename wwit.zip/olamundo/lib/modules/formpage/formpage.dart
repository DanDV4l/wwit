import 'package:flutter/material.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/objects/textfield.dart';
import 'package:olamundo/shared/themes/appimages.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class FormPage extends StatefulWidget {
  const FormPage({Key? key}) : super(key: key);

  @override
  _FormPageState createState() => _FormPageState();
}

class _FormPageState extends State<FormPage> {
  @override
  Widget build(BuildContext context) {
    if (MediaQuery.of(context).size.width > 1154) {
      return buildFormPage();
    }
    return buildFormPageMobile();
  }

  Widget buildFormPage() {
    var size = MediaQuery.of(context).size;
    return Scaffold(
        appBar: PreferredSize(
          preferredSize:
              Size.fromHeight(MediaQuery.of(context).size.height * 0.10),
          child: Container(
            color: Colors.black.withOpacity(0),
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height * 0.1,
          ),
        ),
        backgroundColor: Colors.black,
        body: SingleChildScrollView(
          child: Container(
            width: size.width,
            height: size.height * 0.9,
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage(AppImages.worldblur), fit: BoxFit.cover)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    VerticalDivider(),
                    Column(
                      children: [
                        buildLogoLarge(),
                        Text("SOLICITAR ATENDIMENTO", style: Styles.textTitle)
                      ],
                    ),
                    Container(
                      child: Column(
                        children: [
                          buildFormField(
                            size: size,
                            label: "Seu nome: ",
                          ),
                          buildFormField(
                            size: size,
                            label: "Telefone para contato: ",
                          ),
                          buildFormField(size: size, label: "E-mail: "),
                          buildFormField(
                              size: size,
                              label: "Como podemos ajudar? ",
                              large: 6),
                          Wrap(
                            children: [
                              IconButton(
                                  onPressed: () {},
                                  icon: Icon(
                                    Icons.done_rounded,
                                    color: Colors.green,
                                    size: 40,
                                  )),
                              IconButton(
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                  icon: Icon(
                                    Icons.close,
                                    color: Colors.red,
                                    size: 40,
                                  ))
                            ],
                          )
                        ],
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        ));
  }

  Widget buildFormPageMobile() {
    var size = MediaQuery.of(context).size;
    return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          leading: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(
                Icons.close,
                color: Colors.red,
                size: 40,
              )),
          backgroundColor: Colors.green.shade900.withOpacity(0),
          actions: [
            IconButton(
                onPressed: () {},
                icon: Icon(
                  Icons.done_rounded,
                  color: Colors.green,
                  size: 40,
                )),
            VerticalDivider()
          ],
        ),
        body: SingleChildScrollView(
          child: Container(
            width: size.width,
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage(AppImages.worldblur), fit: BoxFit.cover)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    VerticalDivider(),
                    buildLogoLarge(),
                    Text("SOLICITAR ATENDIMENTO", style: Styles.textTitle),
                    Container(
                      child: Column(
                        children: [
                          buildFormField(
                            size: size,
                            label: "Seu nome: ",
                          ),
                          buildFormField(
                            size: size,
                            label: "Telefone para contato: ",
                          ),
                          buildFormField(size: size, label: "E-mail: "),
                          buildFormField(
                              size: size,
                              label: "Como podemos ajudar? ",
                              large: 6),
                        ],
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        ));
  }
}
