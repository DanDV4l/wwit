import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:olamundo/controllers/form.dart';
import 'package:olamundo/shared/objects/buttons.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/objects/textfield.dart';
import 'package:olamundo/shared/themes/appimages.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class FormPage extends StatefulWidget {
  const FormPage({Key? key}) : super(key: key);

  @override
  _FormPageState createState() => _FormPageState();
}

class _FormPageState extends State<FormPage> {
  @override
  Widget build(BuildContext context) {
    if (MediaQuery.of(context).size.width > 1154) {
      return buildFormPage();
    }
    return buildFormPageMobile();
  }

  Widget buildFormPage() {
    var size = MediaQuery.of(context).size;
    return Scaffold(
        appBar: PreferredSize(
          preferredSize:
              Size.fromHeight(MediaQuery.of(context).size.height * 0.10),
          child: Container(
            color: Colors.black.withOpacity(0),
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height * 0.1,
          ),
        ),
        backgroundColor: Colors.black,
        body: SingleChildScrollView(
          child: Container(
            width: size.width,
            height: size.height * 0.9,
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage(AppImages.worldblur), fit: BoxFit.cover)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    VerticalDivider(),
                    Column(
                      children: [
                        buildLogoLarge(),
                        Text("SOLICITAR ATENDIMENTO", style: Styles.textTitle),
                        Container(
                          margin: EdgeInsets.only(top: 25, bottom: 50),
                          width: MediaQuery.of(context).size.width * 0.25,
                          child: Text.rich(
                            TextSpan(
                                text: "AVISO: ",
                                style: TextStyle(
                                    color: Colors.red,
                                    fontWeight: FontWeight.w900,
                                    fontSize: 23),
                                children: [
                                  TextSpan(
                                      text:
                                          " A disponibilidade do atendimento presencial pode variar de acordo com a sua localização.",
                                      style: TextStyle(
                                          fontSize: 20,
                                          color: Colors.white,
                                          fontWeight: FontWeight.w100))
                                ]),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ],
                    ),
                    Container(
                      child: Column(
                        children: [
                          buildFormField(
                            controller: cName,
                            size: size,
                            label: "Seu nome: ",
                          ),
                          buildFormField(
                            controller: cPhone,
                            size: size,
                            label: "Telefone para contato: ",
                          ),
                          buildFormField(
                              controller: cEmail,
                              size: size,
                              label: "E-mail: "),
                          buildFormField(
                              controller: cMessage,
                              size: size,
                              label: "Como podemos ajudar? ",
                              large: 6),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              buildFormButton(
                                  icon: Icons.done_rounded,
                                  color: Colors.green,
                                  text: "SOLICITAR",
                                  onTap: () {
                                    Dados dados = Dados();
                                    dados.addChamados();
                                    cName.text = '';
                                    cPhone.text = '';
                                    cEmail.text = '';
                                    cMessage.text = '';
                                    Navigator.pop(context);
                                  }),
                              buildFormButton(
                                  icon: Icons.close,
                                  color: Colors.red,
                                  text: "CANCELAR",
                                  onTap: () {
                                    cName.text = '';
                                    cPhone.text = '';
                                    cEmail.text = '';
                                    cMessage.text = '';
                                    Navigator.pop(context);
                                  })
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        ));
  }

  Widget buildFormPageMobile() {
    var size = MediaQuery.of(context).size;
    return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          leading: IconButton(
              onPressed: () {
                cName.text = '';
                cPhone.text = '';
                cEmail.text = '';
                cMessage.text = '';
                Navigator.pop(context);
              },
              icon: Icon(
                Icons.close,
                color: Colors.red,
                size: 40,
              )),
          backgroundColor: Colors.green.shade900.withOpacity(0),
          actions: [
            IconButton(
                onPressed: () {},
                icon: Icon(
                  Icons.done_rounded,
                  color: Colors.green,
                  size: 40,
                )),
            VerticalDivider()
          ],
        ),
        body: SingleChildScrollView(
          child: Container(
            width: size.width,
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage(AppImages.worldblur), fit: BoxFit.cover)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    VerticalDivider(),
                    buildLogoLarge(),
                    Text("SOLICITAR ATENDIMENTO", style: Styles.textTitle),
                    Container(
                      child: Column(
                        children: [
                          buildFormField(
                            controller: cName,
                            size: size,
                            label: "Seu nome: ",
                          ),
                          buildFormField(
                            controller: cPhone,
                            size: size,
                            label: "Telefone para contato: ",
                          ),
                          buildFormField(
                              controller: cEmail,
                              size: size,
                              label: "E-mail: "),
                          buildFormField(
                              controller: cMessage,
                              size: size,
                              label: "Como podemos ajudar? ",
                              large: 6),
                        ],
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        ));
  }
}
