import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:olamundo/shared/apptexts.dart';
import 'package:olamundo/shared/objects/buttons.dart';
import 'package:olamundo/shared/objects/codestatus.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/objects/textbox.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    var _size = MediaQuery.of(context).size; //captura dimensões da tela

    return Theme(
      data: ThemeData(
          highlightColor: Colors.green,
          scrollbarTheme: ScrollbarThemeData(
              thumbColor:
                  MaterialStateProperty.all(Colors.green.withOpacity(0.2)))),
      child: SingleChildScrollView(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        //Container principal da página
        child: Container(
          width: _size.width,
          margin: EdgeInsets.only(bottom: 15),
          padding: EdgeInsets.all(5),
          decoration: BoxDecoration(),
          //coluna principal de elementos
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              //container com logotipo - início
              Container(
                  width: _size.width,
                  height: _size.height * 0.40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(0),
                        bottomRight: Radius.circular(100)),
                    /* image: DecorationImage(
                        image: AssetImage(AppImages.world), fit: BoxFit.cover)*/
                  ),
                  child: Center(
                      child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      buildLogoLarge(),
                      Text("Sua ideia do tamanho do mundo.",
                          style: Styles.textTitle),
                      Container(
                        margin: EdgeInsets.only(bottom: 15, top: 15),
                        color: Colors.white,
                        height: 0,
                        width: MediaQuery.of(context).size.width * 0.1,
                      ),
                      Text("ACESSO RÁPIDO:",
                          style: TextStyle(color: Colors.white)),
                      Container(
                        margin: EdgeInsets.only(top: 10),
                        width: MediaQuery.of(context).size.width * 0.25,
                        decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.02),
                            borderRadius:
                                BorderRadius.all(Radius.circular(12))),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            buildFormButton(
                                color: Colors.white,
                                icon: Icons.app_registration,
                                text: "SOLICITAR\nATENDIMENTO",
                                onTap: () {
                                  Navigator.pushNamed(context, "/request");
                                }),
                            buildFormButton(
                                color: Colors.white,
                                icon: Icons.pending_actions_outlined,
                                text: "ANDAMENTO\nDO SERVIÇO",
                                onTap: () {
                                  aviso(context);
                                }),
                          ],
                        ),
                      ),
                    ],
                  ))),
              CarouselSlider(
                  options: CarouselOptions(
                      autoPlay: true,
                      autoPlayInterval: Duration(seconds: 7),
                      enableInfiniteScroll: false,
                      aspectRatio: 5,
                      enlargeCenterPage: true),
                  items: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        buildContentHorizontal(context,
                            image: AppTexts.img1,
                            title: AppTexts.title1,
                            text: AppTexts.text1),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        buildContentHorizontalInverse(context,
                            image: AppTexts.img2,
                            title: AppTexts.title2,
                            text: AppTexts.text2)
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        buildContentHorizontal(context,
                            image: AppTexts.img3,
                            title: AppTexts.title3,
                            text: AppTexts.text3),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        buildContentHorizontalInverse(context,
                            image: AppTexts.img4,
                            title: AppTexts.title4,
                            text: AppTexts.text4),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        buildContentHorizontal(context,
                            image: AppTexts.img5,
                            title: AppTexts.title5,
                            text: AppTexts.text5),
                      ],
                    )
                  ]),

              Container(
                margin: EdgeInsets.only(top: 30, bottom: 10),
                width: 50,
                height: 1,
                color: Colors.grey,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
