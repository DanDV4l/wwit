import 'package:flutter/material.dart';
import 'package:olamundo/shared/apptexts.dart';
import 'package:olamundo/shared/objects/buttons.dart';
import 'package:olamundo/shared/objects/codestatus.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/objects/textbox.dart';
import 'package:olamundo/shared/themes/appimages.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    var _size = MediaQuery.of(context).size; //captura dimensões da tela

    return SingleChildScrollView(
      physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
      //Container principal da página
      child: Container(
        width: _size.width,
        margin: EdgeInsets.only(bottom: 15),
        padding: EdgeInsets.all(5),
        decoration: BoxDecoration(),
        //coluna principal de elementos
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            //container com logotipo - início
            Container(
                width: _size.width,
                height: _size.height * 0.40,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(0),
                      bottomRight: Radius.circular(100)),
                  /* image: DecorationImage(
                        image: AssetImage(AppImages.world), fit: BoxFit.cover)*/
                ),
                child: Center(
                    child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    buildLogoLarge(),
                    Text("Sua ideia do tamanho do mundo.",
                        style: Styles.textTitle),
                    Container(
                      margin: EdgeInsets.only(bottom: 15, top: 15),
                      color: Colors.white,
                      height: 0,
                      width: MediaQuery.of(context).size.width * 0.1,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        buildFormButton(
                            color: Colors.white,
                            icon: Icons.app_registration,
                            text: "SOLICITAR\nATENDIMENTO",
                            onTap: () {
                              Navigator.pushNamed(context, "/request");
                            }),
                        buildFormButton(
                            color: Colors.white,
                            icon: Icons.pending_actions_rounded,
                            text: "ANDAMENTO\nDO SERVIÇO",
                            onTap: () {
                              checkStatus(context);
                            }),
                      ],
                    ),
                  ],
                ))),
            //container com logotipo - final
            //linha 1 - caixa de texto e citação
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                buildContentHorizontal(context,
                    image: AppTexts.img1,
                    title: AppTexts.title1,
                    text: AppTexts.text1),
                Container(
                  width: 300,
                  child: Text(
                      "\"Entre o 0 e 1 de nossa consciência humana, existem infinitas possibilidades.\"",
                      textAlign: TextAlign.end,
                      style: Styles.textTitle),
                ),
                VerticalDivider()
              ],
            ),
            //linha 2 - citação e caixa de texto
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                VerticalDivider(),
                Container(
                  width: 300,
                  child: Text(
                    "\“Nunca se compare com ninguém neste mundo. Caso o faça, entenda que você estará insultando a si mesmo.\”",
                    style: Styles.textTitle,
                    textAlign: TextAlign.start,
                  ),
                ),
                buildContentHorizontalInverse(context,
                    image: AppTexts.img2,
                    title: AppTexts.title2,
                    text: AppTexts.text2)
              ],
            ),
            //linha 3 - caixa de texto e citação
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                buildContentHorizontal(context,
                    image: AppTexts.img3,
                    title: AppTexts.title3,
                    text: AppTexts.text3),
                Container(
                  width: 300,
                  child: Text(
                      "\"Nós só podemos ver um pouco do futuro, mas o suficiente para perceber que há muito a fazer.\"",
                      textAlign: TextAlign.end,
                      style: Styles.textTitle),
                ),
                VerticalDivider()
              ],
            ),
            //linha 4 - citação e caixa de texto
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                VerticalDivider(),
                Container(
                  width: 300,
                  child: Text(
                    "\"O mundo é muito maior do que apenas 0 e 1. Pense diferente!\"",
                    style: Styles.textTitle,
                    textAlign: TextAlign.start,
                  ),
                ),
                buildContentHorizontalInverse(context,
                    image: AppTexts.img4,
                    title: AppTexts.title4,
                    text: AppTexts.text4),
              ],
            ),
            //linha 5 - caixa de texto e citação
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                buildContentHorizontal(context,
                    image: AppTexts.img5,
                    title: AppTexts.title5,
                    text: AppTexts.text5),
                Container(
                  width: 300,
                  child: Text(
                      "\"Se você mostrar o problemas às pessoas, e indicar uma solução, elas vão se mobilizar para agir.\"",
                      textAlign: TextAlign.end,
                      style: Styles.textTitle),
                ),
                VerticalDivider()
              ],
            ),
            Text(
              "TECNOLOGIAS",
              style: Styles.textTitleBox,
            ),
            Wrap(
              children: [
                buildButton(
                    image: AppImages.flutter, label: "FLUTTER", onTap: null),
                buildButton(
                    image: AppImages.firebase, label: "FIREBASE", onTap: null),
                buildButton(
                    image: AppImages.api, label: "RESTFUL API", onTap: null),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
