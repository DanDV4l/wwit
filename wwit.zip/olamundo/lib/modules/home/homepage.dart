import 'package:flutter/material.dart';
import 'package:olamundo/shared/apptexts.dart';
import 'package:olamundo/shared/objects/buttons.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/objects/textbox.dart';
import 'package:olamundo/shared/themes/appimages.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  var _size;

  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;

    return SingleChildScrollView(
      physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
      child: Container(
        width: _size.width,
        margin: EdgeInsets.only(bottom: 15),
        padding: EdgeInsets.all(5),
        decoration: BoxDecoration(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
                width: _size.width,
                height: _size.height * 0.75,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(0),
                        bottomRight: Radius.circular(100)),
                    image: DecorationImage(
                        image: AssetImage(AppImages.world), fit: BoxFit.cover)),
                child: Center(
                    child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    buildLogoLarge(),
                    Text("Sua ideia do tamanho do mundo.",
                        style: Styles.textTitle),
                  ],
                ))),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                buildContentHorizontal(context,
                    image: AppTexts.img1,
                    title: AppTexts.title1,
                    text: AppTexts.text1),
                Container(
                  width: 300,
                  child: Text(
                      "\"Entre o 0 e 1 de nossa consciência humana, existem infinitas possibilidades.\"",
                      textAlign: TextAlign.end,
                      style: Styles.textTitle),
                ),
                VerticalDivider()
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                VerticalDivider(),
                Container(
                  width: 300,
                  child: Text(
                    "\“Nunca se compare com ninguém neste mundo. Caso o faça, entenda que você estará insultando a si mesmo.\”",
                    style: Styles.textTitle,
                    textAlign: TextAlign.start,
                  ),
                ),
                buildContentHorizontalInverse(context,
                    image: AppTexts.img2,
                    title: AppTexts.title2,
                    text: AppTexts.text2)
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                buildContentHorizontal(context,
                    image: AppTexts.img3,
                    title: AppTexts.title3,
                    text: AppTexts.text3),
                Container(
                  width: 300,
                  child: Text(
                      "\"Nós só podemos ver um pouco do futuro, mas o suficiente para perceber que há muito a fazer.\"",
                      textAlign: TextAlign.end,
                      style: Styles.textTitle),
                ),
                VerticalDivider()
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                VerticalDivider(),
                Container(
                  width: 300,
                  child: Text(
                    "\"O mundo é muito maior do que apenas 0 e 1. Pense diferente!\"",
                    style: Styles.textTitle,
                    textAlign: TextAlign.start,
                  ),
                ),
                buildContentHorizontalInverse(context,
                    image: AppTexts.img4,
                    title: AppTexts.title4,
                    text: AppTexts.text4),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                buildContentHorizontal(context,
                    image: AppTexts.img5,
                    title: AppTexts.title5,
                    text: AppTexts.text5),
                Container(
                  width: 300,
                  child: Text(
                      "\"Se você mostrar o problemas às pessoas, e indicar uma solução, elas vão se mobilizar para agir.\"",
                      textAlign: TextAlign.end,
                      style: Styles.textTitle),
                ),
                VerticalDivider()
              ],
            ),
          ],
        ),
      ),
    );
  }
}
