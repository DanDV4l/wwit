import 'package:flutter/material.dart';
import 'package:olamundo/shared/apptexts.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/objects/mobiletextbox.dart';
import 'package:olamundo/shared/themes/appimages.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class HomePageMobile extends StatefulWidget {
  const HomePageMobile({Key? key}) : super(key: key);

  @override
  _HomePageMobileState createState() => _HomePageMobileState();
}

class _HomePageMobileState extends State<HomePageMobile> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    return SingleChildScrollView(
      physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
      child: Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: size.width,
              height: 300,
              margin: EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage(AppImages.earth), fit: BoxFit.cover)),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    buildLogoLarge(),
                    Text(
                      "Sua ideia do tamanho do mundo.",
                      style: Styles.textTitle,
                      textAlign: TextAlign.center,
                    )
                  ],
                ),
              ),
            ),
            buildMobileTextBox(size,
                title: AppTexts.title1,
                text: AppTexts.text1,
                image: AppImages.laptop),
            buildMobileTextBox(size,
                title: AppTexts.title2,
                text: AppTexts.text2,
                image: AppImages.prototype),
            buildMobileTextBox(size,
                title: AppTexts.title3,
                text: AppTexts.text3,
                image: AppImages.code),
            buildMobileTextBox(size,
                title: AppTexts.title4,
                text: AppTexts.text4,
                image: AppImages.fix),
            buildMobileTextBox(
              size,
              title: AppTexts.title5,
              text: AppTexts.text5,
              image: AppImages.network,
            )
          ],
        ),
      ),
    );
  }
}
