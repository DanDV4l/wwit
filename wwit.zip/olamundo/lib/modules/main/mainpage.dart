import 'package:flutter/material.dart';
import 'package:olamundo/modules/home/homepage.dart';
import 'package:olamundo/modules/home/homepagemobile.dart';
import 'package:olamundo/modules/services/servicepagemobile.dart';
import 'package:olamundo/modules/services/servicespage.dart';
import 'package:olamundo/modules/showroom/showroompage.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/objects/tabbar.dart';
import 'package:olamundo/shared/themes/appcolors.dart';
import 'package:olamundo/shared/themes/appimages.dart';

var screenSize;

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  @override
  Widget build(BuildContext context) {
    var _size = MediaQuery.of(context).size;
    screenSize = _size;
    return DefaultTabController(
        initialIndex: 0,
        length: 5,
        child: Scaffold(
            backgroundColor: Colors.black,
            bottomNavigationBar: _size.width < 1150
                ? Container(
                    child: buildTabBar(context),
                    decoration: BoxDecoration(
                      color: AppColors.appBar,
                    ),
                  )
                : Container(
                    height: 0,
                  ),
            appBar: PreferredSize(
              preferredSize: Size.fromHeight(_size.width > 1154 ? 50 : 50),
              child: Container(
                  decoration: BoxDecoration(
                    color: Colors.black,
                  ),
                  width: MediaQuery.of(context).size.width,
                  padding: EdgeInsets.only(right: 30, left: 30),
                  height: _size.width > 1154 ? 50 : 50,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      buildLogo(),
                      _size.width > 1154
                          ? Expanded(
                              child: buildTabBar(context),
                            )
                          : Container(),
                    ],
                  )),
            ),
            body: Container(
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage(AppImages.worldblur),
                      fit: BoxFit.cover)),
              child: TabBarView(
                children: [
                  _size.width >= 1154 ? HomePage() : HomePageMobile(),
                  _size.width >= 1154 ? ServicesPage() : ServicePageMobile(),
                  ShowRoomPage(),
                  Container(color: Colors.green.withOpacity(0.3)),
                  Container(color: Colors.amber.withOpacity(0.3)),
                ],
              ),
            )));
  }
}
