import 'package:flutter/material.dart';
import 'package:olamundo/controllers/form.dart';
import 'package:olamundo/modules/about/aboutpage.dart';
import 'package:olamundo/modules/about/aboutpagemobile.dart';
import 'package:olamundo/modules/home/homepage.dart';
import 'package:olamundo/modules/home/homepagemobile.dart';
import 'package:olamundo/modules/services/servicespage.dart';
import 'package:olamundo/modules/services/servicespagemobile.dart';
import 'package:olamundo/modules/showroom/showroompage.dart';
import 'package:olamundo/modules/support/supportpagemobile.dart';
import 'package:olamundo/modules/support/supportpage.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/objects/tabbar.dart';
import 'package:olamundo/shared/themes/appcolors.dart';
import 'package:olamundo/shared/themes/appimages.dart';

//captura tamanho da tela para repassar aos dimensionamento das fontes
var screenSize;

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  @override
  Widget build(BuildContext context) {
    //captura dimensões da tela
    var _size = MediaQuery.of(context).size;
    screenSize = _size;

    return DefaultTabController(
        //Aba inicial
        initialIndex: 0,
        //Quantidade de abas da página
        length: 5,
        child: Scaffold(
            //cor de fundo padrão da aplicação
            backgroundColor: Colors.black,
            //início barra superior
            appBar: PreferredSize(
              preferredSize: Size.fromHeight(
                  //Altura barra superior
                  _size.width > 1154 ? 50 : 50),
              child: Container(
                  decoration: BoxDecoration(
                    //Cor de fundo barra superior
                    color: Colors.black,
                  ),
                  //largura barra superior
                  width: MediaQuery.of(context).size.width,
                  //distanciamento interno da barra superior
                  padding: EdgeInsets.only(right: 30, left: 30),
                  //altura interna da barra superior
                  height: _size.width > 1154 ? 50 : 50,
                  //conteúdo da barra superior
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      //logo
                      buildLogo(),
                      //exibe abas na barra superior caso a largura da tela seja > 1154
                      _size.width > 1154
                          ? Expanded(
                              child: buildTabBar(context),
                            )
                          : Container(),
                    ],
                  )),
            ),
            //final barra superior
            //início barra inferior - caso a largura da tela seja < 1150
            bottomNavigationBar: _size.width < 1150
                ? Container(
                    child: buildTabBar(context),
                    decoration: BoxDecoration(
                      color: AppColors.appBar,
                    ),
                  )
                : Container(
                    height: 0,
                  ), //final barra inferior
            body: Container(
              decoration:
                  BoxDecoration(image: DecorationImage(image: AssetImage(
                      //imagem de fundo padrão
                      AppImages.worldblur), fit: BoxFit.cover)),
              child: TabBarView(
                children: [
                  //conteúdo das abas
                  //aba 0
                  _size.width >= 1154 ? HomePage() : HomePageMobile(),
                  //aba 1
                  _size.width >= 1200 ? ServicesPage() : ServicesPageMobile(),
                  //aba 2
                  ShowRoomPage(),
                  //aba 3
                  _size.width >= 1154 ? SupportPage() : SupportPageMobile(),
                  //aba 4
                  _size.width >= 1154 ? AboutPage() : AboutPageMobile(),
                ],
              ),
            )));
  }
}
