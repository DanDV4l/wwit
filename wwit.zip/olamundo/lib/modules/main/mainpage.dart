import 'package:flutter/material.dart';
import 'package:olamundo/modules/about/aboutpage.dart';
import 'package:olamundo/modules/about/aboutpagemobile.dart';
import 'package:olamundo/modules/home/homepage.dart';
import 'package:olamundo/modules/home/homepagemobile.dart';
import 'package:olamundo/modules/services/servicespage.dart';
import 'package:olamundo/modules/services/servicespagemobile.dart';
import 'package:olamundo/modules/showroom/showroompage.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/objects/tabbar.dart';
import 'package:olamundo/shared/themes/appcolors.dart';
import 'package:olamundo/shared/themes/appimages.dart';

var screenSize; //captura tamanho da tela para repassar aos dimensionamento das fontes

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  @override
  Widget build(BuildContext context) {
    var _size = MediaQuery.of(context).size;
    screenSize = _size;
    return DefaultTabController(
        initialIndex: 0, //Aba inicial
        length: 5, //Quantidade de abas da página
        child: Scaffold(
            backgroundColor: Colors.black, //cor de fundo padrão da aplicação

            appBar: PreferredSize(
              preferredSize: Size.fromHeight(
                  _size.width > 1154 ? 50 : 50), //Altura barra superior
              child: Container(
                  decoration: BoxDecoration(
                    color: Colors.black, //Cor de fundo barra superior
                  ),
                  width: MediaQuery.of(context)
                      .size
                      .width, //largura barra superior
                  padding: EdgeInsets.only(
                      right: 30,
                      left: 30), //distanciamento interno da barra superior
                  height: _size.width > 1154
                      ? 50
                      : 50, //altura interna da barra superior
                  child: Row(
                    //conteúdo da barra superior
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      buildLogo(), //logo
                      _size.width > 1154
                          ? Expanded(
                              child: buildTabBar(
                                  context), //exibe abas na barra superior caso a largura da tela seja > 1154
                            )
                          : Container(),
                    ],
                  )),
            ),
            bottomNavigationBar: _size.width <
                    1150 //início barra inferior - caso a largura da tela seja < 1150
                ? Container(
                    child: buildTabBar(context),
                    decoration: BoxDecoration(
                      color: AppColors.appBar,
                    ),
                  )
                : Container(
                    height: 0,
                  ), //final barra inferior //final barra superior
            body: Container(
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage(
                          AppImages.worldblur), //imagem de fundo padrão
                      fit: BoxFit.cover)),
              child: TabBarView(
                children: [
                  //conteúdo das abas
                  _size.width >= 1154 ? HomePage() : HomePageMobile(), //aba 0
                  _size.width >= 1200
                      ? ServicesPage()
                      : ServicesPageMobile(), //aba 1
                  ShowRoomPage(), //aba 2
                  Container(color: Colors.green.withOpacity(0.3)), //aba 3
                  _size.width >= 1154 ? AboutPage() : AboutPageMobile(), //aba 4
                ],
              ),
            )));
  }
}
