import 'package:flutter/material.dart';
import 'package:olamundo/shared/apptexts.dart';
import 'package:olamundo/shared/objects/buttons.dart';
import 'package:olamundo/shared/objects/codestatus.dart';
import 'package:olamundo/shared/objects/descriptionbox.dart';
// ignore: avoid_web_libraries_in_flutter
import 'dart:html' as html;
import 'package:olamundo/shared/themes/appimages.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class ServicesPage extends StatefulWidget {
  const ServicesPage({Key? key}) : super(key: key);

  @override
  _ServicesPageState createState() => _ServicesPageState();
}

class _ServicesPageState extends State<ServicesPage> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.all(10),
      child: SingleChildScrollView(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        child: Column(
          children: [
            Wrap(
              children: [
                buildServiceButton(size, onTap: () {
                  description(
                      context, ServicesTexts.title1, ServicesTexts.text1);
                },
                    title: ServicesTexts.title1,
                    text: ServicesTexts.text1,
                    image: ServicesTexts.img1),
                buildServiceButton(size, onTap: () {
                  description(
                      context, ServicesTexts.title2, ServicesTexts.text2);
                },
                    title: ServicesTexts.title2,
                    text: ServicesTexts.text2,
                    image: ServicesTexts.img2),
                buildServiceButton(size, onTap: () {
                  description(
                      context, ServicesTexts.title3, ServicesTexts.text3);
                },
                    title: ServicesTexts.title3,
                    text: ServicesTexts.text3,
                    image: ServicesTexts.img3),
              ],
            ),
            Container(
              margin: EdgeInsets.only(bottom: 15),
              color: Colors.white,
              height: 0.5,
              width: size.width * 0.5,
            ),
            Text("Verifique aqui o andamento do seu serviço.",
                style: Styles.appText),
            buildCodeStatus(context),
            Container(
              margin: EdgeInsets.only(bottom: 15),
              color: Colors.white,
              height: 0.5,
              width: size.width * 0.5,
            ),
            Container(
              width: size.width * 0.4,
              child: Column(
                children: [
                  Text("SOFTWARES ESSENCIAIS", style: Styles.textTitle),
                  Text(
                    "Para a realização de atendimento remoto, é necessário que você possua um dos softwares indicados abaixo instalado no seu computador.",
                    style: Styles.appText,
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                buildButton(
                    image: AppImages.anydesk,
                    label: "Anydesk",
                    onTap: () {
                      html.window.open('https://anydesk.com/pt/downloads/', '');
                    }),
                buildButton(
                    image: AppImages.winassist,
                    label: "Assist. do Windows",
                    onTap: null),
                buildButton(
                    image: AppImages.teamviewer,
                    label: "Team Viewer",
                    onTap: () {
                      html.window.open('https://www.teamviewer.com/', '');
                    }),
              ],
            )
          ],
        ),
      ),
    );
  }
}
