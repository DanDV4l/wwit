import 'package:flutter/material.dart';
import 'package:olamundo/shared/apptexts.dart';
import 'package:olamundo/shared/objects/buttons.dart';
import 'package:olamundo/shared/objects/codestatus.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/objects/textbox.dart';

import 'package:olamundo/shared/themes/apptextstyles.dart';

class ServicesPage extends StatefulWidget {
  const ServicesPage({Key? key}) : super(key: key);

  @override
  _ServicesPageState createState() => _ServicesPageState();
}

class _ServicesPageState extends State<ServicesPage> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
      child: Container(
        padding: EdgeInsets.only(bottom: 30),
        width: MediaQuery.of(context).size.width,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Column(
              children: [
                buildServiceBox(context,
                    image: ServicesTexts.img1,
                    title: ServicesTexts.title1,
                    text: ServicesTexts.text1,
                    desc: ServicesTexts.desc1),
                Container(
                  margin: EdgeInsets.only(bottom: 15, top: 15),
                  color: Colors.white,
                  height: 0.2,
                  width: MediaQuery.of(context).size.width * 0.1,
                ),
                buildServiceBoxInverse(context,
                    image: ServicesTexts.img2,
                    title: ServicesTexts.title2,
                    text: ServicesTexts.text2,
                    desc: ServicesTexts.desc2),
                Container(
                  margin: EdgeInsets.only(bottom: 15, top: 15),
                  color: Colors.white,
                  height: 0.2,
                  width: MediaQuery.of(context).size.width * 0.1,
                ),
                buildServiceBox(context,
                    image: ServicesTexts.img3,
                    title: ServicesTexts.title3,
                    text: ServicesTexts.text3,
                    desc: ServicesTexts.desc3),
                Container(
                  margin: EdgeInsets.only(bottom: 15, top: 15),
                  color: Colors.white,
                  height: 0.2,
                  width: MediaQuery.of(context).size.width * 0.1,
                ),
                buildServiceBoxInverse(context,
                    image: ServicesTexts.img4,
                    title: ServicesTexts.title4,
                    text: ServicesTexts.text4,
                    desc: ServicesTexts.desc4)
              ],
            ),
            Container(
              width: MediaQuery.of(context).size.width * 0.30,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 150,
                  ),
                  buildLogoLarge(),
                  Text(
                    "SERVIÇOS",
                    style: Styles.textTitleBox,
                  ),
                  Wrap(
                    children: [
                      buildIconButton(
                          icon: Icons.app_registration_rounded,
                          label: "SOLICITAR\nATENDIMENTO",
                          onTap: () {
                            Navigator.pushNamed(context, "/request");
                          }),
                      buildIconButton(
                          icon: Icons.pending_actions_rounded,
                          label: "STATUS DO\nSERVIÇO",
                          onTap: () {
                            checkStatus(context);
                          }),
                      buildIconButton(
                          icon: Icons.widgets,
                          label: "SOFTWARES\nESSENCIAIS",
                          onTap: () {}),
                    ],
                  ),
                  Container(
                    margin: EdgeInsets.only(bottom: 15, top: 15),
                    color: Colors.white,
                    height: 0.2,
                    width: MediaQuery.of(context).size.width * 0.1,
                  ),
                  Text.rich(
                    TextSpan(
                        text: "AVISO: ",
                        style: TextStyle(
                            color: Colors.red,
                            fontWeight: FontWeight.w900,
                            fontSize: 23),
                        children: [
                          TextSpan(
                              text:
                                  " A disponibilidade do atendimento presencial pode variar de acordo com a sua localização.",
                              style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w100))
                        ]),
                    textAlign: TextAlign.start,
                  ),
                  Container(
                    margin: EdgeInsets.only(bottom: 15, top: 15),
                    color: Colors.white,
                    height: 0.1,
                    width: MediaQuery.of(context).size.width * 0.1,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
