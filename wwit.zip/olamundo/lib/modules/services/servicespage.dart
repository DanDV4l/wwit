import 'package:flutter/material.dart';
import 'package:olamundo/shared/apptexts.dart';
import 'package:olamundo/shared/objects/buttons.dart';
import 'package:olamundo/shared/objects/codestatus.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/objects/textbox.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class ServicesPage extends StatefulWidget {
  const ServicesPage({Key? key}) : super(key: key);

  @override
  _ServicesPageState createState() => _ServicesPageState();
}

class _ServicesPageState extends State<ServicesPage> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height * 0.9,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SingleChildScrollView(
              child: Container(
                width: MediaQuery.of(context).size.width * 0.5,
                margin: EdgeInsets.only(top: 15),
                padding:
                    EdgeInsets.only(top: 15, right: 15, bottom: 15, left: 15),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(50))),
                child: Column(
                  children: [
                    buildServiceBox(context,
                        image: ServicesTexts.img1,
                        title: ServicesTexts.title1,
                        text: ServicesTexts.text1,
                        desc: ServicesTexts.desc1),
                    buildServiceBoxInverse(context,
                        image: ServicesTexts.img2,
                        title: ServicesTexts.title2,
                        text: ServicesTexts.text2,
                        desc: ServicesTexts.desc2),
                    buildServiceBox(context,
                        image: ServicesTexts.img3,
                        title: ServicesTexts.title3,
                        text: ServicesTexts.text3,
                        desc: ServicesTexts.desc3),
                    buildServiceBoxInverse(context,
                        image: ServicesTexts.img4,
                        title: ServicesTexts.title4,
                        text: ServicesTexts.text4,
                        desc: ServicesTexts.desc4)
                  ],
                ),
              ),
            ),
            VerticalDivider(
              color: Colors.white.withOpacity(0.4),
            ),
            Container(
              width: MediaQuery.of(context).size.width * 0.30,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    buildLogoLarge(),
                    Text(
                      "SERVIÇOS",
                      style: Styles.textTitle,
                    ),
                    Container(
                      margin: EdgeInsets.only(bottom: 25, top: 50),
                      color: Colors.white,
                      height: 0.2,
                      width: MediaQuery.of(context).size.width * 0.1,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        buildIconButton(
                            icon: Icons.work,
                            label: "SOLICITAR\nATENDIMENTO",
                            onTap: () {
                              Navigator.pushNamed(context, "/request");
                            }),
                        buildIconButton(
                            icon: Icons.pageview_rounded,
                            label: "STATUS DO\nSERVIÇO",
                            onTap: () {
                              checkStatus(context);
                            }),
                        buildIconButton(
                            icon: Icons.widgets,
                            label: "SOFTWARES\nESSENCIAIS",
                            onTap: () {}),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
