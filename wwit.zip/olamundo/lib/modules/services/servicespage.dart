import 'package:flutter/material.dart';
import 'package:olamundo/shared/apptexts.dart';
import 'package:olamundo/shared/objects/buttons.dart';
import 'package:olamundo/shared/objects/codestatus.dart';
import 'package:olamundo/shared/objects/descriptionbox.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class ServicesPage extends StatelessWidget {
  const ServicesPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 60,
              ),
              buildLogoLarge(),
              Text(
                "SERVIÇOS",
                style: Styles.textTitleBox,
              ),
              Container(
                margin: EdgeInsets.only(bottom: 45, top: 15),
                color: Colors.white,
                height: 0.2,
                width: MediaQuery.of(context).size.width * 0.1,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextButton(
                      onPressed: () {
                        description(context, ServicesTexts.title1,
                            "${ServicesTexts.text1}\n\n${ServicesTexts.desc1}");
                      },
                      child: Text('DESENVOLVIMENTO\nDE SOFTWARE',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white))),
                  Container(
                    margin: EdgeInsets.only(left: 15, right: 15),
                    color: Colors.white,
                    width: 1,
                    height: 15,
                  ),
                  TextButton(
                      onPressed: () {
                        description(context, ServicesTexts.title2,
                            "${ServicesTexts.text2}\n\n${ServicesTexts.desc2}");
                      },
                      child: Text('DESIGN\nGRÁFICO',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white))),
                  Container(
                    margin: EdgeInsets.only(left: 15, right: 15),
                    color: Colors.white,
                    width: 1,
                    height: 15,
                  ),
                  TextButton(
                      onPressed: () {
                        description(context, ServicesTexts.title3,
                            "${ServicesTexts.text3}\n\n${ServicesTexts.desc3}");
                      },
                      child: Text('SUPORTE\nTÉCNICO',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white))),
                  Container(
                    margin: EdgeInsets.only(left: 15, right: 15),
                    color: Colors.white,
                    width: 1,
                    height: 15,
                  ),
                  TextButton(
                      onPressed: () {
                        description(context, ServicesTexts.title4,
                            "${ServicesTexts.text4}\n\n${ServicesTexts.desc4}");
                      },
                      child: Text('CONSULTORIA\nEM TI',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white)))
                ],
              ),
              Container(
                margin: EdgeInsets.only(bottom: 15, top: 45),
                color: Colors.white,
                height: 0.2,
                width: MediaQuery.of(context).size.width * 0.1,
              ),
              Wrap(
                children: [
                  buildIconButton(
                      icon: Icons.app_registration_rounded,
                      label: "SOLICITAR\nATENDIMENTO",
                      onTap: () {
                        Navigator.pushNamed(context, "/request");
                      }),
                  buildIconButton(
                      icon: Icons.pending_actions_rounded,
                      label: "STATUS DO\nSERVIÇO",
                      onTap: () {
                        checkStatus(context);
                      }),
                  buildIconButton(
                      icon: Icons.widgets,
                      label: "SOFTWARES\nESSENCIAIS",
                      onTap: () {}),
                ],
              ),
              Container(
                margin: EdgeInsets.only(bottom: 15, top: 15),
                color: Colors.white,
                height: 0.2,
                width: MediaQuery.of(context).size.width * 0.1,
              ),
              Container(
                width: MediaQuery.of(context).size.width * 0.3,
                child: Text.rich(
                  TextSpan(
                      text: "AVISO: ",
                      style: TextStyle(
                          color: Colors.red,
                          fontWeight: FontWeight.w900,
                          fontSize: 23),
                      children: [
                        TextSpan(
                            text:
                                " A disponibilidade do atendimento presencial pode variar de acordo com a sua localização.",
                            style: TextStyle(
                                fontSize: 20,
                                color: Colors.white,
                                fontWeight: FontWeight.w100))
                      ]),
                  textAlign: TextAlign.start,
                ),
              ),
            ],
          ),
        )
      ],
    );
  }
}
