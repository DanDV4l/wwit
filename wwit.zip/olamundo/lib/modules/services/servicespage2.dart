import 'package:flutter/material.dart';
import 'package:olamundo/shared/apptexts.dart';
import 'package:olamundo/shared/objects/buttons.dart';
import 'package:olamundo/shared/objects/codestatus.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/objects/textbox.dart';
import 'package:olamundo/shared/themes/appimages.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class ServicesPage extends StatefulWidget {
  const ServicesPage({Key? key}) : super(key: key);

  @override
  _ServicesPageState createState() => _ServicesPageState();
}

class _ServicesPageState extends State<ServicesPage> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.all(10),
      child: SingleChildScrollView(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              margin: EdgeInsets.only(top: 20),
              width: size.width * 0.85,
              decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.0),
                  borderRadius: BorderRadius.all(Radius.circular(15))),
              child: Column(
                children: [
                  Container(
                      width: size.width,
                      height: size.height * 0.45,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(0),
                            bottomRight: Radius.circular(100)),
                      ),
                      child: Center(
                          child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          buildLogoLarge(),
                          Text("SERVIÇOS", style: Styles.textTitle),
                          Container(
                            margin: EdgeInsets.only(bottom: 15, top: 50),
                            color: Colors.white,
                            height: 0.5,
                            width: size.width * 0.5,
                          ),
                          Text(
                            "Verifique aqui o andamento do seu serviço.",
                            style: Styles.appText,
                            textAlign: TextAlign.center,
                          ),
                          buildCodeStatus(context),
                          Container(
                            color: Colors.white,
                            height: 0.5,
                            width: size.width * 0.5,
                          ),
                        ],
                      ))),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      buildServiceBox(context,
                          image: ServicesTexts.img1,
                          title: ServicesTexts.title1,
                          text: ServicesTexts.text1,
                          desc: ServicesTexts.desc1),
                    ],
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      buildServiceBoxInverse(context,
                          image: ServicesTexts.img2,
                          title: ServicesTexts.title2,
                          text: ServicesTexts.text2,
                          desc: ServicesTexts.desc2)
                    ],
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      buildServiceBox(context,
                          image: ServicesTexts.img3,
                          title: ServicesTexts.title3,
                          text: ServicesTexts.text3,
                          desc: ServicesTexts.desc3),
                    ],
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      buildServiceBoxInverse(context,
                          image: ServicesTexts.img4,
                          title: ServicesTexts.title4,
                          text: ServicesTexts.text4,
                          desc: ServicesTexts.desc4)
                    ],
                  ),
                  Divider(
                    color: Colors.white,
                  ),
                  Text("SOFTWARES ESSENCIAIS", style: Styles.textTitle),
                  Text(
                    "Estes softwares são essenciais para que possam ser realizados atendimentos remotos.",
                    style: Styles.appText,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      buildEssentialButton(
                          image: AppImages.anydesk, label: "AnyDesk"),
                      buildEssentialButton(
                          image: AppImages.winassist,
                          label: "Assistência do Windows"),
                      buildEssentialButton(
                          image: AppImages.teamviewer, label: "Team Viewer"),
                    ],
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
