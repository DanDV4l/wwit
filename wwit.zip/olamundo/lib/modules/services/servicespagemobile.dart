import 'package:flutter/material.dart';
import 'package:olamundo/shared/apptexts.dart';
import 'package:olamundo/shared/objects/codestatus.dart';
import 'package:olamundo/shared/objects/descriptionbox.dart';
import 'package:olamundo/shared/objects/mobiletextbox.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class ServicesPageMobile extends StatefulWidget {
  const ServicesPageMobile({Key? key}) : super(key: key);

  @override
  _ServicesPageMobileState createState() => _ServicesPageMobileState();
}

class _ServicesPageMobileState extends State<ServicesPageMobile> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return SingleChildScrollView(
      physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
      child: Container(
        child: Column(
          children: [
            Container(
                width: size.width,
                height: size.height * 0.25,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(0),
                      bottomRight: Radius.circular(100)),
                ),
                child: Center(
                    child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Verifique aqui o andamento do seu serviço.",
                      style: Styles.appText,
                      textAlign: TextAlign.center,
                    ),
                    buildCodeStatus(context),
                    Container(
                      margin: EdgeInsets.only(top: 15),
                      color: Colors.white,
                      height: 0.5,
                      width: size.width * 0.5,
                    ),
                  ],
                ))),
            buildMobileTextBox(size,
                title: ServicesTexts.title1,
                text: ServicesTexts.text1,
                image: ServicesTexts.img1),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                    onPressed: () {
                      description(
                          context, ServicesTexts.title1, ServicesTexts.desc1);
                    },
                    child: Text(
                      "Saiba mais",
                      style: TextStyle(
                          color: Colors.green, fontWeight: FontWeight.bold),
                    )),
                VerticalDivider()
              ],
            ),
            Divider(
              color: Colors.grey.shade600,
            ),
            buildMobileTextBox(size,
                title: ServicesTexts.title2,
                text: ServicesTexts.text2,
                image: ServicesTexts.img2),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                    onPressed: () {
                      description(
                          context, ServicesTexts.title2, ServicesTexts.desc2);
                    },
                    child: Text(
                      "Saiba mais",
                      style: TextStyle(
                          color: Colors.green, fontWeight: FontWeight.bold),
                    )),
                VerticalDivider()
              ],
            ),
            Divider(
              color: Colors.grey.shade600,
            ),
            buildMobileTextBox(size,
                title: ServicesTexts.title3,
                text: ServicesTexts.text3,
                image: ServicesTexts.img3),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                    onPressed: () {
                      description(
                          context, ServicesTexts.title3, ServicesTexts.desc3);
                    },
                    child: Text(
                      "Saiba mais",
                      style: TextStyle(
                          color: Colors.green, fontWeight: FontWeight.bold),
                    )),
                VerticalDivider()
              ],
            ),
            Divider(
              color: Colors.grey.shade600,
            ),
            buildMobileTextBox(size,
                title: ServicesTexts.title4,
                text: ServicesTexts.text4,
                image: ServicesTexts.img4),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                    onPressed: () {
                      description(
                          context, ServicesTexts.title4, ServicesTexts.desc4);
                    },
                    child: Text(
                      "Saiba mais",
                      style: TextStyle(
                          color: Colors.green, fontWeight: FontWeight.bold),
                    )),
                VerticalDivider()
              ],
            ),
          ],
        ),
      ),
    );
  }
}
