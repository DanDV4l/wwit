import 'package:flutter/material.dart';
import 'package:olamundo/shared/objects/buttons.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/themes/appimages.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class SupportPage extends StatelessWidget {
  const SupportPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        padding: EdgeInsets.only(top: 25),
        width: MediaQuery.of(context).size.width,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            buildLogoLarge(),
            Text(
              'SUPORTE',
              style: Styles.textTitle,
            ),
            Container(
              margin: EdgeInsets.only(top: 20, bottom: 20),
              width: MediaQuery.of(context).size.width * 0.40,
              child: Text(
                  'Os softwares listados abaixo são essenciais para que possamos prosseguir com o atendimento remoto. Faça o download dos softwares que foram solicitados para o atendimento e aguarde instruções.',
                  style: Styles.appText),
            ),
            Container(
              margin: EdgeInsets.only(top: 25, bottom: 25),
              width: 200,
              height: 1,
              color: Colors.white.withOpacity(0),
            ),
            Container(
              width: MediaQuery.of(context).size.width * 0.70,
              margin: EdgeInsets.only(bottom: 40),
              decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.3),
                  borderRadius: BorderRadius.all(Radius.circular(15))),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Column(
                    children: [
                      buildVerticalIconButton(
                          icon: AppImages.winassist,
                          label: "Asstência rápida",
                          onTap: () {}),
                      buildVerticalIconButton(
                          icon: AppImages.anydesk,
                          label: "Anydesk",
                          onTap: () {}),
                      buildVerticalIconButton(
                          icon: AppImages.teamviewer,
                          label: "Teamviewer",
                          onTap: () {}),
                    ],
                  ),
                  Container(
                    height: 250,
                    width: 0.5,
                    color: Colors.white,
                    margin: EdgeInsets.all(35),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Softwares de assistência remota.",
                          style: Styles.textTitle),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.35,
                        child: Text(
                            "São softwares que possibilitam o acesso e controle do computador remotamente, isto é, vai ser como se o técnico estivesse presencialmente mexendo no seu computador tentando encontrar e solucionar o problema em alguma configuração ou qualquer problema relacionado ao software.",
                            style: Styles.appText),
                      ),
                    ],
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
