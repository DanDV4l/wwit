import 'package:flutter/material.dart';
import 'package:olamundo/shared/objects/buttons.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/themes/appimages.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class SupportPageMobile extends StatelessWidget {
  const SupportPageMobile({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        padding: EdgeInsets.only(top: 25),
        width: MediaQuery.of(context).size.width,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            buildLogoLarge(),
            Text(
              'SUPORTE',
              style: Styles.textTitle,
            ),
            Container(
              margin: EdgeInsets.only(top: 20, bottom: 20),
              width: MediaQuery.of(context).size.width,
              child: Text(
                'Os softwares listados abaixo são essenciais para que possamos prosseguir com o atendimento remoto. Faça o download dos softwares que foram solicitados para o atendimento e aguarde instruções.',
                style: Styles.appText,
                textAlign: TextAlign.center,
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 25, bottom: 25),
              width: 200,
              height: 1,
              color: Colors.white.withOpacity(0.5),
            ),
            Wrap(
              children: [
                buildVerticalIconButton(
                    icon: AppImages.winassist,
                    label: "Asstência rápida",
                    onTap: () {}),
                buildVerticalIconButton(
                    icon: AppImages.anydesk, label: "Anydesk", onTap: () {}),
                buildVerticalIconButton(
                    icon: AppImages.teamviewer,
                    label: "Teamviewer",
                    onTap: () {}),
              ],
            )
          ],
        ),
      ),
    );
  }
}
