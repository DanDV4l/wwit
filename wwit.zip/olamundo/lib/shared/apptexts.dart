import 'package:olamundo/shared/themes/appimages.dart';

class AppTexts {
  //caixa 1
  static final String title1 = "Tire suas ideias do papel";
  static final String text1 =
      "O mundo mudou e com o avanço da tecnologia, hoje os negócios também se estendem para o mundo virtual. Que tal colocar em prática suas ideias?\nCom um site e/ou aplicativo, você tem a garantia de que seu produto ou serviço chegará a um público consideravelmente maior. Ou também caso você precise apenas otimizar ou automatizar um processo em seu negócio, também podemos te ajudar a atingir seus objetivos!";
  static final img1 = AppImages.laptop;
  static final link1 = "";

  //caixa3
  static final String title2 = "Faça a prototipagem da sua ideia";
  static final String text2 =
      "Que tal ter um modelo interativo da sua ideia para que possa apresentar ao seu público alvo? A criação de um protótipo é importante, pois, eles permitem testar e validar se suas expectativas sobre a sua ideia correspondem ao que pode ser a realidade, além de permitir que alterações e correções sejam feitas facilmente antes mesmo do trabalho de desenvolvimento começar.";
  static final String img2 = AppImages.prototype;
  static final link2 = "";

  //caixa2
  static final String title3 = "Disponibilize para todas as plataformas";
  static final String text3 =
      "O Flutter é uma tecnologia desenvolvida pelo Google e permite que uma mesma aplicação rode em diversas plataformas com pouquíssimos ajustes no seu código-fonte. O que garante que sua ideia atinja um público ainda maior. Sua aplicação poderá ser executada no Android, iOS, Windows, Mac, Linux e Web.";
  static final img3 = AppImages.code;
  static final link3 = "";

  //caixa4
  static final String title4 = "Seu computador está lento?";
  static final String text4 =
      "Muitas vezes, o problema de seu computador pode ser resolvido de uma forma muito mais simples do que você imagina. Confira nossas dicas para resolver os problemas mais comuns, caso não funcione, entre em contato e solicite um atendimento.";
  static final img4 = AppImages.fix;
  static final link4 = "";

  //caixa5
  static final String title5 = "Problemas na rede de sua casa ou empresa?";
  static final String text5 =
      "A internet está lenta, não consegue acessar documentos em um computador que está em outro ponto do imóvel ou a impressora compartilhada não está imprimindo?\nConte conosco para solucionar estes e outros problemas na sua rede local!";
  static final img5 = AppImages.network;
  static final link5 = "";
}

class ServicesTexts {
  //box 1
  static final String title1 = "DESENVOLVIMENTO DE SOFTWARE";
  static final String text1 =
      "- Desenvolvimento de sites\n- Aplicativos Android\n- Aplicativos iOS\n- Desenvolvimento de aplicações Windows, Linux e Mac\n- Prototipagem\n\n\nQue tal conversarmos sobre a sua ideia?";
  static final String img1 = AppImages.mobileDev;
  //box2
  static final String title2 = "DESIGN GRÁFICO";
  static final String text2 =
      "- Edição e restauração de fotografias\n- Cartões de visita (impresso e virtual)\n- Logotipos\n- Convites\n- Panfletos\n- Folders\n- Desenhos vetoriais";
  static final String img2 = AppImages.graphic;
  //box3
  static final String title3 = "SUPORTE TÉCNICO";
  static final String text3 =
      "- Atendimento remoto\n- Atendimento presencial (dependendo da sua localidade)\n- Otimização de sistema\n- Montagem e manutenção de computadores\n- Formatação (Mac e PC)\n- instalação de softwares\n- Remoção de malwares\n- Configuração e compartilhamento de impressoras na rede\n- Configuração de redes\n- Configuração de roteadores";
  static final String img3 = AppImages.fix;
}
