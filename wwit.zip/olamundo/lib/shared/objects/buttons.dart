import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';

Widget buildButton({required image, required label, required onTap, size}) {
  return InkWell(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.all(10),
        width: 85,
        // height: 150,
        decoration:
            BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(8))),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              //  width: 40,
              height: 50,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(
                    image,
                  ),
                  fit: BoxFit.fitHeight,
                ),
                borderRadius: BorderRadius.all(Radius.circular(8)),
              ),
            ),
            Divider(
              color: Colors.white,
            ),
            Text(label,
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: size != null ? size : 10))
          ],
        ),
      ));
}

Widget buildIconButton({icon, label, onTap}) {
  return InkWell(
      child: Container(
        width: 130,
        //height: 120,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 50,
              color: Colors.white,
            ),
            Container(
                height: 1,
                width: 20,
                color: Colors.white,
                margin: EdgeInsets.all(15)),
            Text(
              label,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 11, color: Colors.white),
            )
          ],
        ),
      ),
      onTap: onTap);
}

Widget buildFormButton({icon, text, onTap, color, size}) {
  return InkWell(
      child: Container(
        padding: EdgeInsets.only(top: 5),
        margin: EdgeInsets.all(15),
        decoration:
            BoxDecoration(border: Border(top: BorderSide(color: color))),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 30,
              color: color != null ? color : Colors.white,
            ),
            VerticalDivider(),
            AutoSizeText(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: color == null ? Colors.white : color, fontSize: size),
            ),
          ],
        ),
      ),
      onTap: onTap);
}
