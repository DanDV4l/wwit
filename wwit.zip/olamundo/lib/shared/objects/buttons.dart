import 'package:flutter/material.dart';

Widget buildButton({required image, required label, required onTap, size}) {
  return InkWell(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.all(10),
        width: 85,
        // height: 150,
        decoration:
            BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(8))),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              //  width: 40,
              height: 50,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(
                    image,
                  ),
                  fit: BoxFit.fitHeight,
                ),
                borderRadius: BorderRadius.all(Radius.circular(8)),
              ),
            ),
            Divider(
              color: Colors.white,
            ),
            Text(label,
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: size != null ? size : 10))
          ],
        ),
      ));
}

Widget buildIconButton({icon, label, onTap}) {
  return InkWell(
      child: Container(
        width: 130,
        height: 120,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 50,
              color: Colors.white,
            ),
            Text(
              label,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 11, color: Colors.white),
            )
          ],
        ),
      ),
      onTap: onTap);
}
