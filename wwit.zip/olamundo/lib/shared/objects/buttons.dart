import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:olamundo/shared/themes/appimages.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

Widget buildButton({required image, required label, required onTap, size}) {
  return InkWell(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.all(30),
        width: 85,
        // height: 150,
        decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.all(Radius.circular(8))),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 100,
              height: 85,
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.black, width: 3),
                  image: DecorationImage(
                      image: AssetImage(image), fit: BoxFit.cover),
                  borderRadius: BorderRadius.all(Radius.circular(30)),
                  color: Colors.white.withOpacity(0.5)),
            ),
            Divider(
              color: Colors.white,
            ),
            Text(label,
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: size != null ? size : 10))
          ],
        ),
      ));
}

Widget buildServiceButton(size, {title, text, image, onTap}) {
  return InkWell(
    highlightColor: Colors.green,
    child: Container(
      margin: EdgeInsets.all(10),
      child: Column(children: [
        Container(
          width: size.width > 1100 ? 300 : 150,
          height: size.width > 1100 ? 200 : 120,
          decoration: BoxDecoration(
              /*borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(8), topRight: Radius.circular(8)),*/
              borderRadius: BorderRadius.all(Radius.circular(8)),
              image: DecorationImage(
                  image: AssetImage(image),
                  fit: size.width < 800 ? BoxFit.fill : BoxFit.cover)),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                  //width: 300,
                  width: size.width > 1100 ? 300 : 150,
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.black),
                      borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(8),
                          bottomRight: Radius.circular(8)),
                      color: Colors.black.withOpacity(0.7)),
                  child: Container(
                    margin: EdgeInsets.all(15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          title,
                          style: Styles.buttonBox,
                          textAlign: TextAlign.center,
                        ),
                        /* Text(text,
                      style: Styles.appText, textAlign: TextAlign.center),*/
                      ],
                    ),
                  ))
            ],
          ),
        ),
      ]),
    ),
    onTap: onTap,
  );
}

Widget buildEssentialButton({image, label, link}) {
  return Container(
    margin: EdgeInsets.all(10),
    width: 120,
    height: 130,
    padding: EdgeInsets.all(10),
    decoration: BoxDecoration(
        color: Colors.black,
        border: Border.all(color: Colors.white, width: 0.3),
        borderRadius: BorderRadius.all(Radius.circular(15))),
    child: Column(
      children: [
        ClipRRect(
          child: Image.asset(
            image,
            fit: BoxFit.cover,
            height: 70,
            width: 125,
          ),
          borderRadius: BorderRadius.all(Radius.circular(15)),
        ),
        Container(
          margin: EdgeInsets.all(5),
          height: 2,
          width: 30,
          color: Colors.white,
        ),
        AutoSizeText(
          label,
          style: Styles.appText,
          minFontSize: 10,
          maxFontSize: 10,
          textAlign: TextAlign.center,
        ),
      ],
    ),
  );
}

Widget buildIconButton({icon, label, onTap}) {
  return InkWell(
      child: Container(
        width: 130,
        height: 120,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 50,
              color: Colors.white,
            ),
            Text(
              label,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 11, color: Colors.white),
            )
          ],
        ),
      ),
      onTap: onTap);
}
