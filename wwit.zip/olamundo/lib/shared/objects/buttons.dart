import 'package:flutter/material.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

Widget buildButton({required image, required label, required onTap, size}) {
  return InkWell(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.all(30),
        width: 100,
        // height: 150,
        decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.5),
            borderRadius: BorderRadius.all(Radius.circular(8))),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 100,
              height: 85,
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage(image), fit: BoxFit.fill),
                  borderRadius: BorderRadius.all(Radius.circular(8)),
                  color: Colors.white.withOpacity(0.5)),
            ),
            Text(label,
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: size != null ? size : 10))
          ],
        ),
      ));
}

Widget buildServiceButton(size, {title, text, image, onTap}) {
  return InkWell(
    child: Container(
      margin: EdgeInsets.all(10),
      child: Column(children: [
        Container(
          width: size.width > 1100 ? 300 : 150,
          height: size.width > 1100 ? 200 : 75,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(8), topRight: Radius.circular(8)),
              image: DecorationImage(
                  image: AssetImage(image),
                  fit: size.width < 800 ? BoxFit.fill : BoxFit.cover)),
        ),
        Container(
            //width: 300,
            width: size.width > 1100 ? 300 : 150,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(8),
                    bottomRight: Radius.circular(8)),
                color: Colors.white.withOpacity(0.1)),
            child: Container(
              margin: EdgeInsets.all(15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    title,
                    style: Styles.buttonBox,
                    textAlign: TextAlign.center,
                  ),
                  /* Text(text,
                      style: Styles.appText, textAlign: TextAlign.center),*/
                ],
              ),
            ))
      ]),
    ),
    onTap: onTap,
  );
}
