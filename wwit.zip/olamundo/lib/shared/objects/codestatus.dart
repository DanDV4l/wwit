import 'package:flutter/material.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

Widget buildCodeStatus(BuildContext context) {
  TextEditingController cCode = TextEditingController();
  double wSize = MediaQuery.of(context).size.width;
  return wSize < 1100 ? cstatusv(context, cCode) : cstatush(context, cCode);
}

Widget cstatusv(context, controller) {
  return Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Text("CÓDIGO DO SERVIÇO:", style: Styles.appText),
      buildTextField(controller: controller),
      ElevatedButton(
        style: ElevatedButton.styleFrom(
          primary: Colors.green.withOpacity(0.4),
        ),
        onPressed: () {
          aviso(context);
        },
        child: Text("OK"),
      )
    ],
  );
}

Widget cstatush(context, controller) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Text("CÓDIGO DO SERVIÇO:", style: Styles.appText),
      buildTextField(controller: controller),
      ElevatedButton(
        style: ElevatedButton.styleFrom(
          primary: Colors.green.withOpacity(0.4),
        ),
        onPressed: () {
          aviso(context);
        },
        child: Text("OK"),
      )
    ],
  );
}

Widget buildTextField({controller}) {
  return Container(
    margin: EdgeInsets.all(15),
    //  height: 28,
    width: 200,
    child: TextField(
        cursorColor: Colors.white,
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.green, fontSize: 16),
        decoration: InputDecoration(
            border: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.white, width: 0.5),
                borderRadius: BorderRadius.all(Radius.circular(8))),
            enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.white, width: 0.5),
                borderRadius: BorderRadius.all(Radius.circular(8))),
            focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.white, width: 0.5),
                borderRadius: BorderRadius.all(Radius.circular(8)))),
        controller: controller),
  );
}

Future aviso(context) async {
  return showDialog<void>(
    barrierColor: Colors.black.withOpacity(0.9),
    context: context,
    barrierDismissible: false, // user must tap button!
    builder: (BuildContext context) {
      return AlertDialog(
        backgroundColor: Colors.grey.shade900,
        title: Text('Recurso em construção', style: Styles.textTitle),
        content: SingleChildScrollView(
          child: ListBody(
            children: <Widget>[
              Container(
                width: 300,
                child: Text(
                  'Estamos trabalhando nisso. Em breve você poderá consultar o andamento do serviço contratado.\n',
                  style: Styles.appText,
                ),
              ),
            ],
          ),
        ),
        actions: <Widget>[
          TextButton(
            child: const Text(
              'Fechar',
              style: TextStyle(color: Colors.white),
            ),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      );
    },
  );
}
