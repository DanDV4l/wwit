import 'package:flutter/material.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

String? code;
TextEditingController cCode = TextEditingController();

Widget buildCodeStatus(BuildContext context) {
  double wSize = MediaQuery.of(context).size.width;
  return wSize < 1220 ? cstatusv(context, cCode) : cstatusv(context, cCode);
}

Widget cstatusv(context, controller) {
  return Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Text("CÓDIGO DO SERVIÇO:", style: Styles.appText),
      buildTextField(controller: controller),
      ElevatedButton(
        style: ElevatedButton.styleFrom(
          primary: Colors.green.withOpacity(0.4),
        ),
        onPressed: () {
          code = cCode.text;
          aviso(context);
        },
        child: Text("OK"),
      )
    ],
  );
}

Widget cstatush(context, controller) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Text("CÓDIGO DO SERVIÇO:", style: Styles.appText),
      buildTextField(controller: controller),
      ElevatedButton(
        style: ElevatedButton.styleFrom(
          primary: Colors.green.withOpacity(0.4),
        ),
        onPressed: () {
          code = cCode.text;
          Navigator.pop(context);
          aviso(context);
        },
        child: Text("OK"),
      )
    ],
  );
}

Widget buildTextField({controller}) {
  return Container(
    margin: EdgeInsets.all(15),
    height: 35,
    width: 200,
    child: TextField(
        cursorColor: Colors.grey.shade600,
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.green, fontSize: 15),
        decoration: InputDecoration(
            border: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.white, width: 0.2),
                borderRadius: BorderRadius.all(Radius.circular(8))),
            enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.green, width: 0.5),
                borderRadius: BorderRadius.all(Radius.circular(15))),
            focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.white, width: 0.5),
                borderRadius: BorderRadius.all(Radius.circular(15)))),
        controller: controller),
  );
}

Future aviso(context, {code}) async {
  return showDialog<void>(
    barrierColor: Colors.black.withOpacity(0.9),
    context: context,
    barrierDismissible: false, // user must tap button!
    builder: (BuildContext context) {
      return AlertDialog(
        backgroundColor: Colors.grey.shade900,
        title: Text('Recurso em construção', style: Styles.textTitle),
        content: SingleChildScrollView(
          child: ListBody(
            children: <Widget>[
              Container(
                width: 300,
                child: Text(
                  'Ainda estamos trabalhando neste recurso.',
                  style: Styles.appText,
                ),
              ),
            ],
          ),
        ),
        actions: <Widget>[
          TextButton(
            child: const Text(
              'Fechar',
              style: TextStyle(color: Colors.white),
            ),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      );
    },
  );
}

Future checkStatus(context, {title, text}) async {
  return showDialog(
    barrierColor: Colors.black.withOpacity(0.8),
    context: context,
    barrierDismissible: true, // user must tap button!
    builder: (BuildContext context) {
      return AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.0),
        //    title: Text(title, style: Styles.textTitle),
        content: Container(
          padding: EdgeInsets.only(top: 0, bottom: 5, right: 15, left: 15),
          height: 270,
          width: 350,
          decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.85),
              border:
                  Border.all(color: Colors.white.withOpacity(0.3), width: 0.85),
              borderRadius: BorderRadius.all(Radius.circular(15))),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  VerticalDivider(),
                  Container(
                    height: 1.5,
                    width: 230,
                    color: Colors.white,
                  ),
                  VerticalDivider(),
                  IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: Icon(
                        Icons.close,
                        color: Colors.red,
                      ))
                ],
              ),
              Text(
                "Ao contratar um serviço você receberá no seu e-mail um código para acompanhar o andamento de sua solicitação, use este código no campo abaixo.\n",
                style: Styles.appText,
                textAlign: TextAlign.center,
              ),
              buildCodeStatus(context),
            ],
          ),
        ),
      );
    },
  );
}
