import 'package:flutter/material.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

Future description(context, title, text) async {
  return showDialog(
    barrierColor: Colors.black.withOpacity(0.9),
    context: context,
    barrierDismissible: true, // user must tap button!
    builder: (BuildContext context) {
      return AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.0),
        //    title: Text(title, style: Styles.textTitle),
        content: Container(
          decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.75),
              border: Border.all(color: Colors.white, width: 1),
              borderRadius: BorderRadius.all(Radius.circular(20)),
              boxShadow: [
                BoxShadow(
                    color: Colors.black,
                    spreadRadius: 3,
                    blurRadius: 30,
                    offset: Offset(3, 5))
              ]),
          padding: EdgeInsets.only(bottom: 0, left: 0, right: 0, top: 0),
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                      color: Colors.grey.shade800,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20))),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      VerticalDivider(),
                      Column(
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width < 800
                                ? MediaQuery.of(context).size.width * 0.4
                                : null,
                            child: Text(
                              title,
                              style: Styles.textTitleBox,
                            ),
                          ),
                        ],
                      ),
                      IconButton(
                          highlightColor: Colors.black.withOpacity(0),
                          hoverColor: Colors.black.withOpacity(0),
                          splashColor: Colors.black.withOpacity(0),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          icon: Icon(Icons.close, color: Colors.red, size: 20)),
                    ],
                  ),
                ),
                Container(
                  margin:
                      EdgeInsets.only(bottom: 20, left: 20, right: 20, top: 0),
                  child: Column(
                    children: [
                      Container(
                        child: Text(
                          text,
                          textAlign: TextAlign.start,
                          style: Styles.appText,
                        ),
                      ),
                      Divider(
                        color: Colors.white.withOpacity(0.3),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          primary: Colors.green,
                        ),
                        onPressed: () {
                          Navigator.pop(context);
                          Navigator.pushNamed(context, "/request");
                        },
                        child: Text(
                          "SOLICITAR",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}
