import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

Widget buildGridItem(size, {required image, required title, required text}) {
  return Container(
    width: 120,
    margin: EdgeInsets.all(5),
    decoration:
        BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(15))),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          margin: EdgeInsets.only(top: 0, bottom: 5),
          height: 85,
          width: 85,
          decoration: BoxDecoration(
              border: Border.all(
                color: Colors.white,
              ),
              image:
                  DecorationImage(image: AssetImage(image), fit: BoxFit.cover),
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(0),
                  topRight: Radius.circular(30),
                  bottomLeft: Radius.circular(30),
                  bottomRight: Radius.circular(0))),
        ),
        AutoSizeText(
          title,
          style: Styles.appText,
          maxLines: 2,
          textAlign: TextAlign.center,
        ),
      ],
    ),
  );
}
