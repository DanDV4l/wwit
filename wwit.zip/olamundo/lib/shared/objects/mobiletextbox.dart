import 'package:flutter/material.dart';
import 'package:olamundo/shared/themes/appcolors.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

Widget buildMobileTextBox(size, {title, text, image}) {
  return Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Container(
        margin: EdgeInsets.only(right: 10, left: 10),
        width: size.width,
        height: 300,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.only(
                topRight: Radius.circular(15), topLeft: Radius.circular(15)),
            image:
                DecorationImage(image: AssetImage(image), fit: BoxFit.cover)),
      ),
      Container(
        width: size.width,
        padding: EdgeInsets.all(15),
        margin: EdgeInsets.only(right: 10, left: 10, bottom: 10),
        decoration: BoxDecoration(
            color: AppColors.textboxBg,
            borderRadius: BorderRadius.only(
                bottomRight: Radius.circular(15),
                bottomLeft: Radius.circular(15))),
        child: Column(
          children: [
            Text(title, style: Styles.textTitle, textAlign: TextAlign.center),
            Text(text, style: Styles.appText, textAlign: TextAlign.center)
          ],
        ),
      )
    ],
  );
}
