import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:olamundo/shared/themes/appimages.dart';

Widget buildSlider(size, items) {
  return Container(
    decoration: BoxDecoration(
        image: DecorationImage(
            image: AssetImage(AppImages.stage), fit: BoxFit.fill)),
    width: 1366,
    height: size.height * 0.6,
    child: CarouselSlider(
        options: CarouselOptions(
            enlargeCenterPage: false,
            enableInfiniteScroll: true,
            autoPlay: true,
            autoPlayInterval: Duration(seconds: 7),
            scrollDirection: Axis.horizontal),
        items: items),
  );
}
