import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';

Widget buildTextListItem(funcao, periodo) {
  return Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
    AutoSizeText(funcao,
        minFontSize: 17,
        maxFontSize: 17,
        maxLines: 2,
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
        )),
    Text(periodo,
        style: TextStyle(
          color: Colors.white,
          fontSize: 14,
        )),
    Container(
      margin: EdgeInsets.all(10),
      height: 1,
      width: 100,
      color: Colors.green,
    ),
  ]);
}

Widget buildTextListItemInverse(funcao, periodo) {
  return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    AutoSizeText(funcao,
        minFontSize: 17,
        maxFontSize: 17,
        maxLines: 2,
        style: TextStyle(
          color: Colors.white,
          fontSize: 18,
          fontWeight: FontWeight.bold,
        )),
    Text(periodo,
        style: TextStyle(
          color: Colors.white,
          fontSize: 14,
        )),
    Container(
      margin: EdgeInsets.all(10),
      height: 1,
      width: 100,
      color: Colors.green,
    ),
  ]);
}
