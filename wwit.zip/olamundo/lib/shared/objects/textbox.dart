import 'package:flutter/material.dart';
import 'package:olamundo/shared/themes/appcolors.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

Widget buildContentHorizontal(BuildContext context,
    {image, title, text, link}) {
  var _size = MediaQuery.of(context).size;
  return Row(
    mainAxisAlignment: MainAxisAlignment.center,
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(
        margin: EdgeInsets.only(bottom: 10, top: 10),
        width: _size.width * 0.30,
        height: _size.height * 0.45,
        decoration: BoxDecoration(
          border: Border.all(width: 0.2),
          image: DecorationImage(image: AssetImage(image), fit: BoxFit.fill),
          borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(200), topLeft: Radius.circular(0)),
        ),
      ),
      Container(
        margin: EdgeInsets.only(bottom: 10, top: 10),
        decoration: BoxDecoration(
            color: AppColors.textboxBg,
            border: Border.all(width: 0.2),
            borderRadius: BorderRadius.only(
                topRight: Radius.circular(200),
                bottomRight: Radius.circular(0))),
        padding: EdgeInsets.all(20),
        width: _size.width * 0.4,
        height: _size.height * 0.45,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SelectableText(
              title,
              style: Styles.textTitle,
            ),
            Container(
              width: _size.width * 0.30,
              height: _size.height * 0.20,
              child: SelectableText(
                text,
                maxLines: 25,
                textAlign: TextAlign.start,
                style: Styles.appText,
                textScaleFactor: 1,
              ),
            ),
          ],
        ),
      ),
    ],
  );
}

Widget buildContentHorizontalInverse(BuildContext context,
    {image, title, text, link}) {
  var _size = MediaQuery.of(context).size;
  return Row(
    mainAxisAlignment: MainAxisAlignment.center,
    crossAxisAlignment: CrossAxisAlignment.end,
    children: [
      Container(
        decoration: BoxDecoration(
            color: AppColors.textboxBg,
            border: Border.all(width: 0.2),
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(200), bottomLeft: Radius.circular(0))),
        padding: EdgeInsets.all(20),
        width: _size.width * 0.4,
        height: _size.height * 0.45,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SelectableText(
              title,
              style: Styles.textTitle,
            ),
            Container(
              width: _size.width * 0.30,
              height: _size.height * 0.20,
              child: SelectableText(
                text,
                maxLines: 25,
                textAlign: TextAlign.end,
                style: Styles.appText,
                textScaleFactor: 1,
              ),
            ),
          ],
        ),
      ),
      Container(
        width: _size.width * 0.30,
        height: _size.height * 0.45,
        decoration: BoxDecoration(
          border: Border.all(width: 0.2),
          image: DecorationImage(image: AssetImage(image), fit: BoxFit.fill),
          borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(0),
              bottomRight: Radius.circular(200)),
        ),
      ),
    ],
  );
}
