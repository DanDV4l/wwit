import 'package:flutter/material.dart';

class AppColors {
  static final appBar = Colors.grey.shade900;
  static final logoMainTitle = Colors.white;
  static final logoAppStudio = Colors.green.shade400;
  static final tabBarSelected = Colors.green.shade500;
  static final tabBarUnselected = Colors.grey.shade300;
  static final textTitle = Colors.white;
  static final textColor = Colors.white;
  static final textboxBg = Colors.black.withOpacity(0.4);
}
