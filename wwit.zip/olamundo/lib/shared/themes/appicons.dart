/*class AppIcons {
  static final android = "assets/icons/android.jpg";
  static final ios = "assets/icons/ios.jpg";
  static final windows = "assets/icons/windows.jpg";
  static final linux = "assets/icons/linux.jpg";
  static final mac = "assets/icons/mac.jpg";
  static final web = "assets/icons/web.jpg";
  static final cartoes = "assets/icons/cartaovisita.jpg";
  static final fotografia = "assets/icons/fotografias.jpg";
  static final sualogo = "assets/icons/sualogo.jpg";
  static final convite = "assets/icons/convite.jpg";
  static final panfleto = "assets/icons/panfleto.jpg";
  static final folder = "assets/icons/folder.jpg";
  static final vetor = "assets/icons/vetor.jpg";
  static final formatar = "assets/icons/formatar.jpg";
  static final impressora = "assets/icons/impressora.jpg";
  static final malwares = "assets/icons/malwares.jpg";
  static final montagem = "assets/icons/montagem.jpg";
  static final otimizar = "assets/icons/otimizar.jpg";
  static final presencial = "assets/icons/presencial.jpg";
  static final rede = "assets/icons/rede.jpg";
  static final remoto = "assets/icons/remoto.jpg";
  static final roteador = "assets/icons/roteador.jpg";
  static final softwares = "assets/icons/softwares.jpg";
}
*/