import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

TextEditingController mNome = TextEditingController();
TextEditingController mContato = TextEditingController();
TextEditingController mMensagem = TextEditingController();

class Contato {
  CollectionReference _mensagens =
      FirebaseFirestore.instance.collection('mensagem');

  Future sendMessage() {
    var _hora = DateFormat.Hm().format(DateTime.now());
    var _data = DateFormat('dd/MM/y').format(DateTime.now());
    var _id = DateFormat('ddMMyHHmm').format(DateTime.now());
    return _mensagens.doc("$_id - ${mNome.text}").set({
      "id": "$_id",
      "data": "$_data",
      "hora": "$_hora",
      "nome": mNome.text,
      "contato": mContato.text,
      "mensagem": mMensagem.text
    });
  }

  void clearFields() {
    mNome.clear();
    mContato.clear();
    mMensagem.clear();
  }
}
