import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

TextEditingController cName = TextEditingController();
TextEditingController cPhone = TextEditingController();
TextEditingController cEmail = TextEditingController();
TextEditingController cMessage = TextEditingController();

class Dados {
  FirebaseFirestore firestore = FirebaseFirestore.instance;

  CollectionReference chamados =
      FirebaseFirestore.instance.collection('chamadosPendentes');
  Future<void> addChamados() {
    return chamados.doc('${cName.text}').set({
      "nome": "${cName.text}",
      "telefone": "${cPhone.text}",
      "email": "${cEmail.text}",
      "mensagem": "${cMessage.text}"
    });
  }
}
