import 'package:flutter/material.dart';

// Import the firebase_core plugin
import 'package:firebase_core/firebase_core.dart';
import 'package:olamundo/appwidget.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(AppWidget());
}

class App extends StatefulWidget {
  @override
  _AppState createState() => _AppState();
}

class _AppState extends State<App> {
  @override
  Widget build(BuildContext context) {
    final Future<FirebaseApp> _initialization = Firebase.initializeApp();

    return FutureBuilder(
      future: _initialization,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          print('erro');
        }

        if (snapshot.connectionState == ConnectionState.done) {
          return AppWidget();
        }

        return Container(
          color: Colors.black,
        );
      },
    );
  }
}
