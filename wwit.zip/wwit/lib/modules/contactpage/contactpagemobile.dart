import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:wwitdev/controllers/contact.dart';
import 'package:wwitdev/shared/objects/buttons.dart';
import 'package:wwitdev/shared/objects/textfield.dart';
import 'package:wwitdev/shared/themes/appimages.dart';
import 'package:wwitdev/shared/themes/apptextstyles.dart';

class ContactPageMobile extends StatefulWidget {
  const ContactPageMobile({Key? key}) : super(key: key);

  @override
  _ContactPageMobileState createState() => _ContactPageMobileState();
}

class _ContactPageMobileState extends State<ContactPageMobile> {
  @override
  Widget build(BuildContext context) {
    return Container(
        padding: const EdgeInsets.all(15),
        width: MediaQuery.of(context).size.width,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text('CONTATO', style: Styles.textTitleBox),
              SizedBox(
                width: MediaQuery.of(context).size.width > 1000
                    ? MediaQuery.of(context).size.width
                    : MediaQuery.of(context).size.width * 0.6,
                child: Text(
                  "Precisa de mais informações, deseja deixar uma crítica ou gostaria de sugerir algo? Está no lugar certo! Basta preencher os campos abaixo.",
                  style: Styles.appText,
                  textAlign: TextAlign.center,
                ),
              ),
              Container(
                margin: const EdgeInsets.all(15),
                width: 300,
                height: 1,
                color: Colors.white,
              ),
              Container(
                margin: const EdgeInsets.only(top: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    buildFormField(
                        size: MediaQuery.of(context).size,
                        label: "Seu nome: ",
                        controller: mNome),
                    buildFormField(
                        size: MediaQuery.of(context).size,
                        label: "Telefone/E-Mail: ",
                        controller: mContato),
                    buildFormField(
                        size: MediaQuery.of(context).size,
                        label: "Mensagem: ",
                        large: 6,
                        controller: mMensagem),
                    Container(
                      margin: const EdgeInsets.only(top: 25, bottom: 25),
                      width: 200,
                      height: 1,
                      color: Colors.white,
                    ),
                    SizedBox(
                      width: 300,
                      child: Text(
                        "Ou fale comigo através do WhatsApp:",
                        style: Styles.appText,
                        textAlign: TextAlign.center,
                      ),
                    ),
                    buildIconButton(
                        icon: AppImages.whatsapp,
                        label: "WhatsApp",
                        onTap: () {
                          launch('https://wa.me/5535988641641');
                        }),
                  ],
                ),
              ),
            ],
          ),
        ));
  }
}
