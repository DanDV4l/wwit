import 'package:flutter/material.dart';
import 'package:olamundo/controllers/contact.dart';
import 'package:olamundo/shared/objects/textfield.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class ContactPageMobile extends StatefulWidget {
  const ContactPageMobile({Key? key}) : super(key: key);

  @override
  _ContactPageMobileState createState() => _ContactPageMobileState();
}

class _ContactPageMobileState extends State<ContactPageMobile> {
  @override
  Widget build(BuildContext context) {
    return Container(
        padding: EdgeInsets.all(15),
        width: MediaQuery.of(context).size.width,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text('FALE COMIGO', style: Styles.textTitleBox),
              Text(
                "Precisa de mais informações, deseja deixar uma crítica ou gostaria de sugerir algo? Está no lugar certo! Basta preencher os campos abaixo.",
                style: Styles.appText,
                textAlign: TextAlign.justify,
              ),
              Container(
                margin: EdgeInsets.all(15),
                width: 300,
                height: 1,
                color: Colors.white,
              ),
              Container(
                margin: EdgeInsets.only(top: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    buildFormField(
                        size: MediaQuery.of(context).size,
                        label: "Seu nome: ",
                        controller: mNome),
                    buildFormField(
                        size: MediaQuery.of(context).size,
                        label: "Telefone/E-Mail: ",
                        controller: mContato),
                    buildFormField(
                        size: MediaQuery.of(context).size,
                        label: "Mensagem: ",
                        large: 6,
                        controller: mMensagem),
                  ],
                ),
              ),
            ],
          ),
        ));
  }
}
