import 'package:flutter/material.dart';
import 'package:olamundo/modules/formpage/formpage.dart';
import 'package:olamundo/modules/formpage/formpagemobile.dart';

class FormControl extends StatefulWidget {
  const FormControl({Key? key}) : super(key: key);

  @override
  _FormControlState createState() => _FormControlState();
}

class _FormControlState extends State<FormControl> {
  @override
  Widget build(BuildContext context) {
    return MediaQuery.of(context).size.width >= 1150
        ? FormPage()
        : FormPageMobile();
  }
}
