import 'package:flutter/material.dart';
import 'package:wwitdev/modules/formpage/formpage.dart';
import 'package:wwitdev/modules/formpage/formpagemobile.dart';

class FormControl extends StatefulWidget {
  const FormControl({Key? key}) : super(key: key);

  @override
  _FormControlState createState() => _FormControlState();
}

class _FormControlState extends State<FormControl> {
  @override
  Widget build(BuildContext context) {
    return MediaQuery.of(context).size.width >= 1150
        ? const FormPage()
        : const FormPageMobile();
  }
}
