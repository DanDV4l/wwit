import 'package:flutter/material.dart';
import 'package:olamundo/controllers/form.dart';
import 'package:olamundo/shared/objects/buttons.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/objects/textfield.dart';
import 'package:olamundo/shared/themes/appimages.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class FormPage extends StatefulWidget {
  const FormPage({Key? key}) : super(key: key);

  @override
  _FormPageState createState() => _FormPageState();
}

class _FormPageState extends State<FormPage> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Theme(
        data: ThemeData(
            highlightColor: Colors.green,
            scrollbarTheme: ScrollbarThemeData(
                thumbColor:
                    MaterialStateProperty.all(Colors.green.withOpacity(0.2)))),
        child: Scaffold(
            appBar: PreferredSize(
              preferredSize:
                  Size.fromHeight(MediaQuery.of(context).size.height * 0.10),
              child: Container(
                color: Colors.black.withOpacity(0),
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * 0.1,
              ),
            ),
            backgroundColor: Colors.black,
            body: Scrollbar(
                isAlwaysShown: true,
                interactive: true,
                child: SingleChildScrollView(
                  child: Container(
                    width: size.width,
                    padding: EdgeInsets.only(bottom: 200),
                    // height: size.height * 0.9,
                    decoration: BoxDecoration(
                        image: DecorationImage(
                            image: AssetImage(AppImages.worldblur),
                            fit: BoxFit.cover)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            VerticalDivider(),
                            Column(
                              children: [
                                buildLogoLarge(),
                                Text("SOLICITAR ATENDIMENTO",
                                    style: Styles.textTitle),
                                Container(
                                  margin: EdgeInsets.only(top: 25, bottom: 50),
                                  width:
                                      MediaQuery.of(context).size.width * 0.25,
                                  child: Text.rich(
                                    TextSpan(
                                        text: "AVISO: ",
                                        style: TextStyle(
                                            color: Colors.red,
                                            fontWeight: FontWeight.w900,
                                            fontSize: 23),
                                        children: [
                                          TextSpan(
                                              text:
                                                  " A disponibilidade do atendimento presencial pode variar de acordo com a sua localização.",
                                              style: TextStyle(
                                                  fontSize: 20,
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w100))
                                        ]),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              ],
                            ),
                            Container(
                              child: Column(
                                children: [
                                  buildFormField(
                                    controller: cName,
                                    size: size,
                                    label: "Seu nome: ",
                                  ),
                                  buildFormField(
                                    controller: cPhone,
                                    size: size,
                                    label: "Telefone para contato: ",
                                  ),
                                  buildFormField(
                                      controller: cEmail,
                                      size: size,
                                      label: "E-mail: "),
                                  buildFormField(
                                      controller: cMessage,
                                      size: size,
                                      label: "Como posso ajudar? ",
                                      large: 6),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      buildFormButton(
                                          icon: Icons.done_rounded,
                                          color: Colors.green,
                                          text: "SOLICITAR",
                                          onTap: () {
                                            Dados dados = Dados();

                                            dados.addChamados();
                                            cName.clear();
                                            cPhone.clear();
                                            cEmail.clear();
                                            cMessage.clear();
                                            Navigator.pop(context);
                                          }),
                                      buildFormButton(
                                          icon: Icons.close,
                                          color: Colors.red,
                                          text: "CANCELAR",
                                          onTap: () {
                                            cName.clear();
                                            cPhone.clear();
                                            cEmail.clear();
                                            cMessage.clear();
                                            Navigator.pop(context);
                                          })
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ))));
  }
}
