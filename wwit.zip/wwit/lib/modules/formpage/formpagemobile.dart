import 'package:flutter/material.dart';
import 'package:olamundo/controllers/form.dart';
import 'package:olamundo/shared/objects/buttons.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/objects/textfield.dart';
import 'package:olamundo/shared/themes/appimages.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class FormPageMobile extends StatefulWidget {
  const FormPageMobile({Key? key}) : super(key: key);

  @override
  _FormPageMobileState createState() => _FormPageMobileState();
}

class _FormPageMobileState extends State<FormPageMobile> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Stack(
      children: [
        Container(
            width: size.width,
            height: size.height,
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage(AppImages.worldblur),
                    fit: BoxFit.cover))),
        Scaffold(
          backgroundColor: Colors.black.withOpacity(0),
          appBar: AppBar(
            title: Column(
              children: [
                buildLogo(),
                Text("SOLICITAR ATENDIMENTO", style: Styles.textTitleBox),
              ],
            ),
            centerTitle: true,
            leading: IconButton(
                onPressed: () {
                  cName.clear();
                  cPhone.clear();
                  cEmail.clear();
                  cMessage.clear();
                  Navigator.pop(context);
                },
                icon: Icon(
                  Icons.close,
                  color: Colors.red,
                  size: 40,
                )),
            backgroundColor: Colors.green.shade900.withOpacity(0),
          ),
          body: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Container(
                      padding: EdgeInsets.all(20),
                      child: Column(
                        children: [
                          buildFormField(
                            controller: cName,
                            size: size,
                            label: "Seu nome: ",
                          ),
                          buildFormField(
                            controller: cPhone,
                            size: size,
                            label: "Telefone para contato: ",
                          ),
                          buildFormField(
                              controller: cEmail,
                              size: size,
                              label: "E-mail: "),
                          buildFormField(
                              controller: cMessage,
                              size: size,
                              label: "Como podemos ajudar? ",
                              large: 6),
                          SizedBox(
                            width: 150,
                            child: buildFormButton(
                                icon: Icons.done,
                                color: Colors.green,
                                text: "Solicitar",
                                onTap: () {
                                  Dados dados = Dados();
                                  dados.addChamados();
                                  cName.clear();
                                  cPhone.clear();
                                  cEmail.clear();
                                  cMessage.clear();

                                  setState(() {});
                                }),
                          )
                        ],
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        )
      ],
    );
  }
}
