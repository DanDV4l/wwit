import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:olamundo/shared/apptexts.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/objects/textbox.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    var _size = MediaQuery.of(context).size; //captura dimensões da tela

    return Theme(
      data: ThemeData(
          //highlightColor: Colors.green,
          scrollbarTheme: ScrollbarThemeData(
              thumbColor:
                  MaterialStateProperty.all(Colors.green.withOpacity(0.2)))),
      child: SingleChildScrollView(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        //Container principal da página
        child: Container(
          width: _size.width,
          margin: EdgeInsets.only(bottom: 15),
          padding: EdgeInsets.all(5),
          decoration: BoxDecoration(),
          //coluna principal de elementos
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              //container com logotipo - início
              Container(
                  width: _size.width,
                  // height: _size.height * 0.25,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(0),
                        bottomRight: Radius.circular(100)),
                  ),
                  child: Center(
                      child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: 57.5,
                      ),
                      buildLogoLarge(),
                      Text("Sua ideia do tamanho do mundo.",
                          style: Styles.textTitle),
                      Container(
                        margin: EdgeInsets.only(bottom: 15, top: 15),
                        color: Colors.white,
                        height: 0,
                        width: MediaQuery.of(context).size.width * 0.1,
                      ),
                      SizedBox(
                        height: 37.5,
                      ),
                    ],
                  ))),
              CarouselSlider(
                  options: CarouselOptions(
                      autoPlay: true,
                      autoPlayInterval: Duration(seconds: 7),
                      enableInfiniteScroll: false,
                      aspectRatio: 4,
                      enlargeCenterPage: true),
                  items: [
                    Center(
                      child: buildContentHorizontal(context,
                          image: AppTexts.img1,
                          title: AppTexts.title1,
                          text: AppTexts.text1),
                    ),
                    Center(
                      child: buildContentHorizontalInverse(context,
                          image: AppTexts.img2,
                          title: AppTexts.title2,
                          text: AppTexts.text2),
                    ),
                    Center(
                      child: buildContentHorizontal(context,
                          image: AppTexts.img3,
                          title: AppTexts.title3,
                          text: AppTexts.text3),
                    ),
                    Center(
                      child: buildContentHorizontalInverse(context,
                          image: AppTexts.img4,
                          title: AppTexts.title4,
                          text: AppTexts.text4),
                    ),
                    Center(
                      child: buildContentHorizontal(context,
                          image: AppTexts.img5,
                          title: AppTexts.title5,
                          text: AppTexts.text5),
                    ),
                  ]),
            ],
          ),
        ),
      ),
    );
  }
}
