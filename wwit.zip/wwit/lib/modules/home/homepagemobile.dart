import 'package:flutter/material.dart';
import 'package:olamundo/shared/apptexts.dart';
import 'package:olamundo/shared/objects/buttons.dart';
import 'package:olamundo/shared/objects/codestatus.dart';
import 'package:olamundo/shared/objects/mobiletextbox.dart';
import 'package:olamundo/shared/themes/appimages.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

class HomePageMobile extends StatefulWidget {
  const HomePageMobile({Key? key}) : super(key: key);

  @override
  _HomePageMobileState createState() => _HomePageMobileState();
}

class _HomePageMobileState extends State<HomePageMobile> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    return SingleChildScrollView(
      physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
      child: Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
                width: size.width,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(0),
                      bottomRight: Radius.circular(100)),
                  /* image: DecorationImage(
                        image: AssetImage(AppImages.world), fit: BoxFit.cover)*/
                ),
                child: Center(
                    child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // buildLogoLarge(),
                    Text(
                      "Sua ideia do tamanho do mundo.",
                      style: Styles.textTitle,
                      textAlign: TextAlign.center,
                    ),
                    Container(
                      margin: EdgeInsets.only(bottom: 5, top: 5),
                      color: Colors.white,
                      height: 0,
                      width: MediaQuery.of(context).size.width * 0.1,
                    ),
                    Container(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          buildFormButton(
                              color: Colors.white,
                              icon: Icons.app_registration,
                              text: "SOLICITAR\nATENDIMENTO",
                              onTap: () {
                                Navigator.pushNamed(context, "/request");
                              },
                              size: 10),
                          buildFormButton(
                              color: Colors.white,
                              icon: Icons.pending_actions_rounded,
                              text: "ANDAMENTO\nDO SERVIÇO",
                              onTap: () {
                                checkStatus(context);
                              },
                              size: 10),
                        ],
                      ),
                    ),
                  ],
                ))),
            //container com logotipo - final
            buildMobileTextBox(size,
                title: AppTexts.title1,
                text: AppTexts.text1,
                image: AppImages.laptop),
            buildMobileTextBox(size,
                title: AppTexts.title2,
                text: AppTexts.text2,
                image: AppImages.prototype),
            buildMobileTextBox(size,
                title: AppTexts.title3,
                text: AppTexts.text3,
                image: AppImages.code),
            buildMobileTextBox(size,
                title: AppTexts.title4,
                text: AppTexts.text4,
                image: AppImages.fix),
            buildMobileTextBox(
              size,
              title: AppTexts.title5,
              text: AppTexts.text5,
              image: AppImages.network,
            )
          ],
        ),
      ),
    );
  }
}
