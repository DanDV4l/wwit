import 'package:flutter/material.dart';
import 'package:olamundo/shared/apptexts.dart';
import 'package:olamundo/shared/objects/mobiletextbox.dart';

class HomePageMobile extends StatefulWidget {
  const HomePageMobile({Key? key}) : super(key: key);

  @override
  _HomePageMobileState createState() => _HomePageMobileState();
}

class _HomePageMobileState extends State<HomePageMobile> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
      child: Container(
        width: MediaQuery.of(context).size.width,
        margin: EdgeInsets.all(10),
        child: Wrap(
          //crossAxisAlignment: CrossAxisAlignment.center,
          alignment: WrapAlignment.center,
          children: [
            buildMobileTextBox(
                image: AppTexts.img1,
                title: AppTexts.title1,
                text: AppTexts.text1),
            buildMobileTextBox(
                image: AppTexts.img2,
                title: AppTexts.title2,
                text: AppTexts.text2),
            buildMobileTextBox(
                image: AppTexts.img3,
                title: AppTexts.title3,
                text: AppTexts.text3),
            buildMobileTextBox(
                image: AppTexts.img4,
                title: AppTexts.title4,
                text: AppTexts.text4),
            buildMobileTextBox(
                image: AppTexts.img5,
                title: AppTexts.title5,
                text: AppTexts.text5)
          ],
        ),
      ),
    );
  }
}
