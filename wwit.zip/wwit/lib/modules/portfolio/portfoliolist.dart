import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:wwitdev/controllers/portfolio.dart';
import 'package:wwitdev/shared/themes/apptextstyles.dart';

Widget buildPortfolioList(context, size) {
  return SizedBox(
    height: size.height * 0.74,
    child: FutureBuilder<List<DataModel>>(
        future: getPortfolio(),
        builder: (context, snapshot) {
          switch (snapshot.connectionState) {
            case ConnectionState.none:
              return Container(
                color: Colors.transparent,
              );
            case ConnectionState.waiting:
              return const Center(
                  child: SizedBox(
                width: 100,
                height: 100,
                child: CircularProgressIndicator(
                  color: Colors.green,
                  backgroundColor: Colors.transparent,
                ),
              ));
            case ConnectionState.active:
              return Container(
                color: Colors.amber,
              );
            case ConnectionState.done:
              return buildList(context, size, snapshot.data);
          }
        }),
  );
}

Widget buildList(context, size, dados) {
  return SizedBox(
    child: ListView.builder(
        itemCount: dados!.length,
        itemBuilder: (context, index) {
          return size.width >= 1024
              ? buildPortfolioTileHorizontal(context, size, dados[index]!)
              : buildPortfolioTileVertical(context, size, dados[index]!);
        }),
  );
}

Widget buildPortfolioTileHorizontal(context, size, dados) {
  return Container(
    margin: const EdgeInsets.all(15),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          child: Image.network(
            dados.imgUrl,
            width: size.width * 0.3,
            fit: BoxFit.fill,
          ),
          borderRadius: const BorderRadius.all(Radius.circular(15)),
        ),
        Container(
          color: Colors.white,
          margin: const EdgeInsets.all(35),
          height: 250,
          width: 1,
        ),
        SizedBox(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                dados.nome,
                style: Styles.textTitle,
              ),
              SizedBox(
                width: size.width * 0.4,
                child: Text(
                  dados.descricao,
                  style: Styles.appTextLarge,
                  textAlign: TextAlign.start,
                ),
              ),
              dados.repositorio != ""
                  ? const SizedBox(
                      height: 15,
                    )
                  : const SizedBox(),
              dados.repositorio != ""
                  ? TextButton(
                      child: Text("VISUALIZAR REPOSITÓRIO",
                          style: Styles.appStudio),
                      onPressed: () {
                        launch('${dados.repositorio}');
                      })
                  : const SizedBox()
            ],
          ),
        )
      ],
    ),
  );
}

Widget buildPortfolioTileVertical(context, size, dados) {
  return Container(
    margin: const EdgeInsets.all(15),
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        ClipRRect(
          child: Image.network(
            dados.imgUrl,
            width: size.width,
          ),
          borderRadius: const BorderRadius.all(Radius.circular(15)),
        ),
        dados.repositorio != ""
            ? TextButton(
                child: Text("VISUALIZAR REPOSITÓRIO", style: Styles.appStudio),
                onPressed: () {
                  launch('${dados.repositorio}');
                })
            : const SizedBox(),
        Container(
          color: Colors.white,
          margin: const EdgeInsets.all(35),
          width: 250,
          height: 1,
        ),
        SizedBox(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                dados.nome,
                style: Styles.textTitle,
              ),
              SizedBox(
                width: size.width,
                child: Text(dados.descricao, style: Styles.appTextLarge),
              ),
            ],
          ),
        )
      ],
    ),
  );
}
