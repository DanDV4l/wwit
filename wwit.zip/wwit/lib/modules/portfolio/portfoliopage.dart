import 'package:flutter/material.dart';
import 'package:wwitdev/modules/portfolio/portfoliolist.dart';

import 'package:wwitdev/shared/objects/logo.dart';
import 'package:wwitdev/shared/themes/apptextstyles.dart';

// import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;

class PortfolioPage extends StatefulWidget {
  const PortfolioPage({Key? key}) : super(key: key);

  @override
  State<PortfolioPage> createState() => _PortfolioPageState();
}

class _PortfolioPageState extends State<PortfolioPage> {
  @override
  Widget build(BuildContext context) {
    ScrollController _scroll = ScrollController();
    var size = MediaQuery.of(context).size;
    return Theme(
      data: ThemeData(
          // highlightColor: Colors.green,
          scrollbarTheme: ScrollbarThemeData(
              isAlwaysShown: true,
              interactive: true,
              thumbColor:
                  MaterialStateProperty.all(Colors.green.withOpacity(0.2)))),
      child: SingleChildScrollView(
          controller: _scroll,
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(
              width: size.width,
              padding: const EdgeInsets.only(top: 25),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  buildLogoLarge(),
                  Text(
                    "",
                    style: Styles.textTitleBox,
                  ),
                  SizedBox(
                    width: size.width,
                    child: buildPortfolioList(
                        context, MediaQuery.of(context).size),
                  )
                ],
              ),
            ),
          ])),
    );
  }
}
