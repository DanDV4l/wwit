import 'package:flutter/material.dart';
import 'package:olamundo/controllers/form.dart';
import 'package:olamundo/shared/apptexts.dart';
import 'package:olamundo/shared/objects/buttons.dart';
import 'package:olamundo/shared/objects/warnings.dart';
import 'package:olamundo/shared/objects/descriptionbox.dart';
import 'package:olamundo/shared/objects/logo.dart';
import 'package:olamundo/shared/objects/textfield.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

bool form = false;

class ServicesPage extends StatefulWidget {
  const ServicesPage({Key? key}) : super(key: key);

  @override
  _ServicesPageState createState() => _ServicesPageState();
}

class _ServicesPageState extends State<ServicesPage> {
  @override
  Widget build(BuildContext context) {
    ScrollController _scroll = ScrollController();

    return Theme(
        data: ThemeData(
            // highlightColor: Colors.green,
            scrollbarTheme: ScrollbarThemeData(
                thumbColor:
                    MaterialStateProperty.all(Colors.green.withOpacity(0.2)))),
        child: Scrollbar(
          controller: _scroll,
          isAlwaysShown: true,
          interactive: true,
          child: SingleChildScrollView(
            controller: _scroll,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: EdgeInsets.only(top: 25),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      buildLogoLarge(),
                      Text(
                        "SERVIÇOS",
                        style: Styles.textTitleBox,
                      ),
                      Container(
                        margin: EdgeInsets.only(bottom: 45, top: 15),
                        color: Colors.white,
                        height: 0,
                        width: MediaQuery.of(context).size.width * 0.1,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TextButton(
                              onPressed: () {
                                description(context, ServicesTexts.title1,
                                    "${ServicesTexts.text1}\n\n${ServicesTexts.desc1}");
                              },
                              child: Text('DESENVOLVIMENTO\nDE SOFTWARE',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Colors.white,
                                  ))),
                          Container(
                            margin: EdgeInsets.only(left: 15, right: 15),
                            color: Colors.white,
                            width: 1,
                            height: 15,
                          ),
                          TextButton(
                              onPressed: () {
                                description(context, ServicesTexts.title2,
                                    "${ServicesTexts.text2}\n\n${ServicesTexts.desc2}");
                              },
                              child: Text('CONSULTORIA\nEM TI',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Colors.white,
                                  ))),
                          Container(
                            margin: EdgeInsets.only(left: 15, right: 15),
                            color: Colors.white,
                            width: 1,
                            height: 15,
                          ),
                          TextButton(
                              onPressed: () {
                                description(context, ServicesTexts.title3,
                                    "${ServicesTexts.text3}\n\n${ServicesTexts.desc3}");
                              },
                              child: Text('SUPORTE\nTÉCNICO',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Colors.white,
                                  ))),
                          Container(
                            margin: EdgeInsets.only(left: 15, right: 15),
                            color: Colors.white,
                            width: 1,
                            height: 15,
                          ),
                          TextButton(
                              onPressed: () {
                                description(context, ServicesTexts.title4,
                                    "${ServicesTexts.text4}\n\n${ServicesTexts.desc4}");
                              },
                              child: Text('ARTES\nVISUAIS',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Colors.white,
                                  )))
                        ],
                      ),
                      Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            border:
                                Border.all(color: Colors.white, width: 0.5)),
                        margin: EdgeInsets.all(30),
                        width: MediaQuery.of(context).size.width * 0.5,
                        child: ExpansionPanelList(
                          expansionCallback: (int index, bool isExpanded) {
                            isExpanded = !isExpanded;
                            form = isExpanded;
                            setState(() {});
                          },
                          children: [
                            ExpansionPanel(
                              canTapOnHeader: true,
                              backgroundColor: Colors.white.withOpacity(0),
                              headerBuilder:
                                  (BuildContext context, bool isExpanded) {
                                return ListTile(
                                  title: Text('SOLICITAR ATENDIMENTO',
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20)),
                                  leading: Icon(
                                    form
                                        ? Icons.keyboard_arrow_up
                                        : Icons.keyboard_arrow_down,
                                    color: Colors.white,
                                  ),
                                );
                              },
                              body: Container(
                                margin: EdgeInsets.all(20),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    buildFormField(
                                      controller: cName,
                                      size: MediaQuery.of(context).size,
                                      label: "Seu nome: ",
                                    ),
                                    buildFormField(
                                      controller: cPhone,
                                      size: MediaQuery.of(context).size,
                                      label: "Telefone para contato: ",
                                    ),
                                    buildFormField(
                                        controller: cEmail,
                                        size: MediaQuery.of(context).size,
                                        label: "E-mail: "),
                                    buildFormField(
                                        controller: cMessage,
                                        size: MediaQuery.of(context).size,
                                        label: "Como posso ajudar? ",
                                        large: 6),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        buildFormButton(
                                            icon: Icons.done_rounded,
                                            color: Colors.green,
                                            text: "SOLICITAR",
                                            onTap: () {
                                              Dados dados = Dados();
                                              dados.addChamados();
                                              cName.clear();
                                              cPhone.clear();
                                              cEmail.clear();
                                              cMessage.clear();
                                              form = false;
                                              setState(() {});
                                            }),
                                        buildFormButton(
                                            icon: Icons.clear_all,
                                            color: Colors.orange,
                                            text: "LIMPAR",
                                            onTap: () {
                                              setState(() {
                                                cName.clear();
                                                cPhone.clear();
                                                cEmail.clear();
                                                cMessage.clear();
                                                form = false;
                                              });
                                            })
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              isExpanded: form,
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 250,
                      child: buildMenuButton(
                          color: Colors.white,
                          icon: Icons.search,
                          text: "ANDAMENTO DO SERVIÇO",
                          onTap: () {
                            aviso(context);
                          }),
                    ),
                    Container(
                        width: 250,
                        child: buildMenuButton(
                            color: Colors.white,
                            icon: Icons.download,
                            text: "SOFTWARES ESSENCIAIS",
                            onTap: () {
                              aviso(context);
                            })),
                  ],
                ),
                Container(
                  margin: EdgeInsets.only(top: 25, bottom: 50),
                  width: MediaQuery.of(context).size.width * 0.25,
                  child: Text.rich(
                    TextSpan(
                        text: "AVISO: ",
                        style: TextStyle(
                            color: Colors.red,
                            fontWeight: FontWeight.w900,
                            fontSize: 23),
                        children: [
                          TextSpan(
                              text:
                                  " A disponibilidade do atendimento presencial pode variar de acordo com a sua localização.",
                              style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w100))
                        ]),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
        ));
  }
}
