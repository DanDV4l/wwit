import 'package:flutter/material.dart';
import 'package:olamundo/controllers/form.dart';
import 'package:olamundo/modules/services/servicespage.dart';
import 'package:olamundo/shared/apptexts.dart';
import 'package:olamundo/shared/objects/buttons.dart';
import 'package:olamundo/shared/objects/descriptionbox.dart';
import 'package:olamundo/shared/objects/mobiletextbox.dart';
import 'package:olamundo/shared/objects/textfield.dart';

class ServicesPageMobile extends StatefulWidget {
  const ServicesPageMobile({Key? key}) : super(key: key);

  @override
  _ServicesPageMobileState createState() => _ServicesPageMobileState();
}

class _ServicesPageMobileState extends State<ServicesPageMobile> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return SingleChildScrollView(
      physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
      child: Container(
        child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(8)),
                  border: Border.all(color: Colors.white, width: 0.5)),
              margin: EdgeInsets.all(30),
              width: MediaQuery.of(context).size.width,
              child: ExpansionPanelList(
                expansionCallback: (int index, bool isExpanded) {
                  isExpanded = !isExpanded;
                  form = isExpanded;
                  setState(() {});
                },
                children: [
                  ExpansionPanel(
                    canTapOnHeader: true,
                    backgroundColor: Colors.white.withOpacity(0),
                    headerBuilder: (BuildContext context, bool isExpanded) {
                      return ListTile(
                        title: Text('SOLICITAR ATENDIMENTO',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 15)),
                        leading: Icon(
                          form
                              ? Icons.keyboard_arrow_up
                              : Icons.keyboard_arrow_down,
                          color: Colors.white,
                        ),
                      );
                    },
                    body: Container(
                      margin: EdgeInsets.all(20),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          buildFormField(
                            controller: cName,
                            size: MediaQuery.of(context).size,
                            label: "Seu nome: ",
                          ),
                          buildFormField(
                            controller: cPhone,
                            size: MediaQuery.of(context).size,
                            label: "Telefone para contato: ",
                          ),
                          buildFormField(
                              controller: cEmail,
                              size: MediaQuery.of(context).size,
                              label: "E-mail: "),
                          buildFormField(
                              controller: cMessage,
                              size: MediaQuery.of(context).size,
                              label: "Como podemos ajudar? ",
                              large: 6),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              buildFormButton(
                                  icon: Icons.done_rounded,
                                  color: Colors.green,
                                  text: "SOLICITAR",
                                  onTap: () {
                                    Dados dados = Dados();
                                    dados.addChamados();
                                    cName.text = '';
                                    cPhone.text = '';
                                    cEmail.text = '';
                                    cMessage.text = '';
                                    form = false;
                                    setState(() {});
                                  }),
                              buildFormButton(
                                  icon: Icons.clear_all,
                                  color: Colors.orange,
                                  text: "LIMPAR",
                                  onTap: () {
                                    setState(() {
                                      cName.text = '';
                                      cPhone.text = '';
                                      cEmail.text = '';
                                      cMessage.text = '';
                                      form = false;
                                    });
                                  })
                            ],
                          ),
                        ],
                      ),
                    ),
                    isExpanded: form,
                  ),
                ],
              ),
            ),
            Divider(),
            buildMobileTextBox(size,
                title: ServicesTexts.title1,
                text: ServicesTexts.text1,
                image: ServicesTexts.img1),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                    onPressed: () {
                      description(
                          context, ServicesTexts.title1, ServicesTexts.desc1);
                    },
                    child: Text(
                      "Saiba mais",
                      style: TextStyle(
                          color: Colors.green, fontWeight: FontWeight.bold),
                    )),
                VerticalDivider()
              ],
            ),
            Divider(
              color: Colors.grey.shade600,
            ),
            buildMobileTextBox(size,
                title: ServicesTexts.title2,
                text: ServicesTexts.text2,
                image: ServicesTexts.img2),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                    onPressed: () {
                      description(
                          context, ServicesTexts.title2, ServicesTexts.desc2);
                    },
                    child: Text(
                      "Saiba mais",
                      style: TextStyle(
                          color: Colors.green, fontWeight: FontWeight.bold),
                    )),
                VerticalDivider()
              ],
            ),
            Divider(
              color: Colors.grey.shade600,
            ),
            buildMobileTextBox(size,
                title: ServicesTexts.title3,
                text: ServicesTexts.text3,
                image: ServicesTexts.img3),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                    onPressed: () {
                      description(
                          context, ServicesTexts.title3, ServicesTexts.desc3);
                    },
                    child: Text(
                      "Saiba mais",
                      style: TextStyle(
                          color: Colors.green, fontWeight: FontWeight.bold),
                    )),
                VerticalDivider()
              ],
            ),
            Divider(
              color: Colors.grey.shade600,
            ),
            buildMobileTextBox(size,
                title: ServicesTexts.title4,
                text: ServicesTexts.text4,
                image: ServicesTexts.img4),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                    onPressed: () {
                      description(
                          context, ServicesTexts.title4, ServicesTexts.desc4);
                    },
                    child: Text(
                      "Saiba mais",
                      style: TextStyle(
                          color: Colors.green, fontWeight: FontWeight.bold),
                    )),
                VerticalDivider()
              ],
            ),
          ],
        ),
      ),
    );
  }
}
