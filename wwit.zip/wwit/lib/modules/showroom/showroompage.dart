import 'package:flutter/material.dart';
// import 'package:wwitdev/shared/objects/largertextbox.dart';
import 'package:wwitdev/shared/objects/logo.dart';
import 'package:wwitdev/shared/themes/apptextstyles.dart';
// import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;

class ShowRoomPage extends StatefulWidget {
  const ShowRoomPage({Key? key}) : super(key: key);

  @override
  _ShowRoomPageState createState() => _ShowRoomPageState();
}

class _ShowRoomPageState extends State<ShowRoomPage> {
  @override
  Widget build(BuildContext context) {
    ScrollController _scroll = ScrollController();

    return Theme(
        data: ThemeData(
            // highlightColor: Colors.green,
            scrollbarTheme: ScrollbarThemeData(
                isAlwaysShown: true,
                interactive: true,
                thumbColor:
                    MaterialStateProperty.all(Colors.green.withOpacity(0.2)))),
        child: SingleChildScrollView(
            controller: _scroll,
            child: Scrollbar(
                controller: _scroll,
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width,
                        padding: const EdgeInsets.only(top: 25),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            buildLogoLarge(),
                            Text(
                              "PORTFÓLIO",
                              style: Styles.textTitleBox,
                            ),
                            /* Wrap(
                              children: [
                                buildLargerTextBox(context),
                                buildLargerTextBox(context),
                                buildLargerTextBox(context),
                                buildLargerTextBox(context),
                                buildLargerTextBox(context),
                                buildLargerTextBox(context),
                              ],
                            )*/
                            const SizedBox(
                              width: 0,
                              height: 200,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(
                                  height: 20,
                                  width: 20,
                                  child: CircularProgressIndicator(
                                    backgroundColor:
                                        Colors.black.withOpacity(0),
                                    color: Colors.grey,
                                  ),
                                ),
                                const SizedBox(
                                  width: 30,
                                ),
                                Text("Em construção...",
                                    style: Styles.textTitleBox),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ]))));
  }
}
