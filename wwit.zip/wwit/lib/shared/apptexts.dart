import 'package:olamundo/shared/themes/appimages.dart';

class AppTexts {
  //caixa 1
  static final String title1 = "Tire suas ideias do papel";
  static final String text1 =
      "O mundo mudou e com o avanço da tecnologia, hoje os negócios também se estendem para o mundo virtual. Que tal colocar em prática suas ideias?\nCom um site e/ou aplicativo, você tem a garantia de que seu produto ou serviço chegará a um público consideravelmente maior. Ou também, caso você precise apenas otimizar ou automatizar um processo em seu negócio, também podemos te ajudar a atingir seus objetivos!";
  static final img1 = AppImages.laptop;
  static final link1 = "";

  //caixa3
  static final String title2 = "Faça a prototipagem da sua ideia";
  static final String text2 =
      "Que tal ter um modelo interativo da sua ideia para que possa apresentar ao seu público alvo? A criação de um protótipo é importante, pois, eles permitem testar e validar se suas expectativas sobre a sua ideia correspondem ao que pode ser a realidade, além de permitir que alterações e correções sejam feitas facilmente antes mesmo do trabalho de desenvolvimento começar.";
  static final String img2 = AppImages.mobileDev;
  static final link2 = "";

  //caixa2
  static final String title3 = "Disponibilize para todas as plataformas";
  static final String text3 =
      "O Flutter é uma tecnologia desenvolvida pelo Google e permite que uma mesma aplicação rode em diversas plataformas com pouquíssimos ajustes no seu código-fonte. O que garante que sua ideia atinja um público ainda maior. Sua aplicação poderá ser executada no Android, iOS, Windows, Mac, Linux e Web.";
  static final img3 = AppImages.code;
  static final link3 = "";

  //caixa4
  static final String title4 = "Seu computador está lento?";
  static final String text4 =
      "Muitas vezes, o problema de seu computador pode ser resolvido de uma forma muito mais simples do que você imagina. Confira nossas dicas para resolver os problemas mais comuns, caso não funcione, entre em contato e solicite um atendimento.";
  static final img4 = AppImages.fix;
  static final link4 = "";

  //caixa5
  static final String title5 = "Problemas na rede de sua casa ou empresa?";
  static final String text5 =
      "A internet está lenta, não consegue acessar documentos em um computador que está em outro ponto do imóvel ou a impressora compartilhada não está imprimindo?\nConte conosco para solucionar estes e outros problemas na sua rede local!";
  static final img5 = AppImages.network;
  static final link5 = "";
}

class ServicesTexts {
  //box 1
  static final String title1 = "Desenvolvimento de Software";
  static final String text1 =
      "O mundo mudou e com o avanço da tecnologia, hoje os negócios também se estendem para o mundo virtual. Que tal colocar em prática suas ideias?\nCom um site e/ou aplicativo, você tem a garantia de que seu produto ou serviço chegará a um público consideravelmente maior. Ou também caso você precise apenas otimizar ou automatizar um processo em seu negócio, também podemos te ajudar a atingir seus objetivos!";
  static final String desc1 =
      "- Aplicativos para Android\n- Aplicativos para iOS\n- Aplicativos para Windows\n- Aplicativos para Linux\n- Aplicativos para Mac\n- Páginas Web";
  static final String img1 = AppImages.mobileDev;
  //box2
  static final String title2 = "Consultoria em TI";
  static final String text2 =
      "Precisa de ajuda na gestão de sua infraestrutura de TI? Vamos juntos identificar as necessidades da sua empresa, elaborar um programa de trabalho personalizado e construir uma solução.";
  static final String desc2 =
      "- Implantação de tecnologia\n- Upgrade de Hardware/Software\n- Planejamento de infraestrutura de rede\n- Aconselhamento de soluções em TI";
  static final String img2 = AppImages.consult;

  //box3
  static final String title3 = "Suporte Técnico";
  static final String text3 =
      "Não tem jeito! Computadores lentos ou que travam com frequência podem prejudicar o seu desempenho profissional ou estragar o seu momento de lazer. Às vezes a solução pode ser mais simples do que você imagina.";
  static final String desc3 =
      "- Atendimento remoto\n- Atendimento presencial (dependendo da sua localidade)\n- Otimização de sistema\n- Montagem e manutenção de computadores\n- Formatação (Mac e PC)\n- instalação de softwares\n- Remoção de malwares\n- Configuração e compartilhamento de impressoras na rede\n- Configuração de redes\n- Configuração de roteadores\n- Backups";
  static final String img3 = AppImages.manutencao;
  //box4
  static final String title4 = "Design Gráfico";
  static final String text4 =
      "Proporcione uma identidade visual à sua marca, faça um cartão de visita personalizado de acordo com sua necessidade. A identidade visual tem forte apelo diante do público e demonstra como você e/ou a sua marca pretende atingir o mercado.";
  static final String desc4 =
      "- Edição e restauração de fotografias\n- Cartões de visita (impresso e virtual)\n- Logotipos\n- Convites\n- Panfletos\n- Folders\n- Desenhos vetoriais";
  static final String img4 = AppImages.graphic;
}

class AboutTexts {
  static final String image1 = AppImages.consult;
  static final String title1 = "SOBRE";
  static final String text1 =
      "Meu nome é Daniel Souza Pinto, criei o site Ww:IT.dev com o intuito de demonstrar minhas habilidades com o Flutter, facilitar o gerenciamento de meus serviços e aumentar o meu alcance como profissional. Trabalho na área de TI há aproximadamente 14 anos. Há cerca de 2 anos e meio estudo para adquirir proficiência no desenvolvimento de aplicações para dispositivos móveis, desktop e web, utilizando o Flutter. Também possuo habilidades com as ferramentas de edição de imagens da Adobe, o Photoshop e o Illustrator. ";
}
