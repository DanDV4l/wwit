import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:wwitdev/shared/themes/apptextstyles.dart';

Widget buildIconButton({icon, label, onTap}) {
  return InkWell(
      child: Container(
        margin: const EdgeInsets.only(right: 50, left: 50),
        width: 160,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              icon,
              width: 30,
              height: 30,
            ),
            Container(
                width: 1,
                height: 20,
                color: Colors.white.withOpacity(0.4),
                margin: const EdgeInsets.all(15)),
            Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 18, color: Colors.white),
            )
          ],
        ),
      ),
      onTap: onTap);
}

Widget buildFormButton({icon, text, onTap, color, size}) {
  return InkWell(
      child: Container(
        padding: const EdgeInsets.only(top: 5),
        margin: const EdgeInsets.all(15),
        decoration:
            BoxDecoration(border: Border(top: BorderSide(color: color))),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 30,
              color: color ?? Colors.white,
            ),
            const VerticalDivider(),
            AutoSizeText(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: color ?? Colors.white,
                fontSize: size,
              ),
            ),
          ],
        ),
      ),
      onTap: onTap);
}

Widget buildMenuButton({icon, text, onTap, color, size}) {
  return InkWell(
      child: Container(
        padding: const EdgeInsets.only(top: 5),
        margin: const EdgeInsets.all(15),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 25,
              color: color ?? Colors.white,
            ),
            Container(
              height: 15,
              width: 1.5,
              margin: const EdgeInsets.only(right: 10, left: 10),
              color: color,
            ),
            AutoSizeText(
              text,
              textAlign: TextAlign.start,
              style: TextStyle(
                color: color ?? Colors.white,
                fontSize: size,
              ),
            ),
          ],
        ),
      ),
      onTap: onTap);
}

buildVerticalIconButton({icon, label, onTap}) {
  return InkWell(
      child: Container(
        width: 280,
        margin: const EdgeInsets.all(5),
        padding: const EdgeInsets.only(
          top: 5,
          bottom: 5,
          left: 25,
        ),
        decoration: BoxDecoration(
            color: Colors.black.withOpacity(0),
            borderRadius: const BorderRadius.all(Radius.circular(8))),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ClipRRect(
              child: Image.asset(
                icon,
                width: 30,
                height: 30,
              ),
              borderRadius: const BorderRadius.all(Radius.circular(5)),
            ),
            Container(
              margin: const EdgeInsets.all(10),
              height: 25,
              width: 1,
              color: Colors.white.withOpacity(0.3),
            ),
            Text(
              label,
              style: Styles.appText,
              textAlign: TextAlign.start,
            ),
          ],
        ),
      ),
      onTap: onTap);
}
