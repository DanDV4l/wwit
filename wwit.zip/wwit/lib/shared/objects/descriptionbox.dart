import 'package:flutter/material.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

Future description(context, title, text) async {
  return showDialog(
    barrierColor: Colors.black.withOpacity(0.5),
    context: context,
    barrierDismissible: true, // user must tap button!
    builder: (BuildContext context) {
      return AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.0),
        //    title: Text(title, style: Styles.textTitle),
        content: Container(
          width: MediaQuery.of(context).size.width < 1000
              ? null
              : MediaQuery.of(context).size.width * 0.4,
          decoration: BoxDecoration(
            color: Colors.black,
            border: Border.all(color: Colors.green, width: 1),
            borderRadius: BorderRadius.all(Radius.circular(8)),
          ),
          padding: EdgeInsets.only(bottom: 0, left: 0, right: 0, top: 0),
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(8),
                          topRight: Radius.circular(8))),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      VerticalDivider(),
                      Column(
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width < 800
                                ? MediaQuery.of(context).size.width * 0.4
                                : null,
                            child: Text(
                              title,
                              style: Styles.textTitleBox,
                            ),
                          ),
                        ],
                      ),
                      IconButton(
                          highlightColor: Colors.black.withOpacity(0),
                          hoverColor: Colors.black.withOpacity(0),
                          splashColor: Colors.black.withOpacity(0),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          icon: Icon(Icons.close, color: Colors.red, size: 20)),
                    ],
                  ),
                ),
                Container(
                  margin:
                      EdgeInsets.only(bottom: 20, left: 20, right: 20, top: 10),
                  child: Column(
                    children: [
                      Container(
                        child: Text(
                          text,
                          textAlign: TextAlign.start,
                          style: Styles.appText,
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}
