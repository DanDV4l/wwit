import 'package:flutter/material.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

Widget buildLogo() {
  return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(15)),
      ),
      child:
          Text.rich(TextSpan(text: "WW", style: Styles.mainTitle2, children: [
        TextSpan(
          text: ":IT",
          style: Styles.mainTitle,
        ),
        TextSpan(
          text: "dev",
          style: Styles.appStudio,
        )
      ])));
}

Widget buildLogoLarge() {
  return Container(
    decoration: BoxDecoration(
      borderRadius: BorderRadius.all(Radius.circular(15)),
    ),
    child: Text.rich(
        TextSpan(text: "WW", style: Styles.mainTitle2Large, children: [
      TextSpan(
        text: ":IT",
        style: Styles.mainTitleLarge,
      ),
      TextSpan(
        text: "dev",
        style: Styles.appStudioLarge,
      )
    ])),
  );
}
