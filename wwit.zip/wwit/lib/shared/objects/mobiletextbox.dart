import 'package:flutter/material.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

Widget buildMobileTextBox({title, text, image, size}) {
  return Container(
    margin: EdgeInsets.all(5),
    width: 380,
    child: Column(
      children: [
        ClipRRect(
          child: Image.asset(image),
          borderRadius: BorderRadius.all(Radius.circular(15)),
        ),
        Text(title, style: Styles.textTitle),
        Text(
          text,
          style: Styles.appText,
        ),
        Divider()
      ],
    ),
  );
}
