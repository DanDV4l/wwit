import 'package:flutter/material.dart';
import 'package:wwitdev/shared/themes/apptextstyles.dart';

Widget buildMobileTextBox({title, text, image, size}) {
  return Container(
    margin: const EdgeInsets.all(5),
    width: 380,
    child: Column(
      children: [
        ClipRRect(
          child: Image.asset(image),
          borderRadius: const BorderRadius.all(Radius.circular(15)),
        ),
        Text(title, style: Styles.textTitle),
        Text(
          text,
          style: Styles.appText,
        ),
        const Divider()
      ],
    ),
  );
}
