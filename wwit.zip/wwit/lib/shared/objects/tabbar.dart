import 'package:flutter/material.dart';
import 'package:olamundo/shared/themes/appcolors.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

Widget buildTabBar(BuildContext context) {
  double _width = MediaQuery.of(context).size.width;

  return Container(
    decoration: BoxDecoration(
        /*border: Border(bottom: BorderSide(color: AppColors.logoMainTitle))*/),
    margin: _width > 1154
        ? EdgeInsets.only(
            left: _width * 0.60,
            right: _width * 0,
          )
        : EdgeInsets.only(bottom: 0),
    child: TabBar(
      isScrollable: false,
      labelColor: AppColors.tabBarSelected,
      unselectedLabelStyle: Styles.tabBarUnselected,
      indicatorColor: AppColors.tabBarSelected,
      unselectedLabelColor: AppColors.tabBarUnselected,
      labelStyle: Styles.tabBar,
      labelPadding: EdgeInsets.only(top: 5),
      tabs: [
        Tab(
          icon: Text("INÍCIO"),
          //text: "Início",
        ),
        Tab(
          icon: Text("SERVIÇOS"),
        ),
        Tab(icon: Text("PORTFÓLIO")),
        //  Tab(icon: Text("SUPORTE")),
        Tab(icon: Text("SOBRE")),
      ],
    ),
  );
}
