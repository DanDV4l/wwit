import 'package:flutter/material.dart';
import 'package:wwitdev/shared/themes/appcolors.dart';
import 'package:wwitdev/shared/themes/apptextstyles.dart';

Widget buildTabBar(BuildContext context) {
  double _width = MediaQuery.of(context).size.width;

  return Container(
    decoration: const BoxDecoration(
        /*border: Border(bottom: BorderSide(color: AppColors.logoMainTitle))*/),
    margin: _width > 1154
        ? EdgeInsets.only(
            left: _width * 0.60,
            right: _width * 0,
          )
        : const EdgeInsets.only(bottom: 0),
    child: TabBar(
      isScrollable: false,
      labelColor: AppColors.tabBarSelected,
      unselectedLabelStyle: Styles.tabBarUnselected,
      indicatorColor: AppColors.tabBarSelected,
      unselectedLabelColor: AppColors.tabBarUnselected,
      labelStyle: Styles.tabBar,
      labelPadding: const EdgeInsets.only(top: 5),
      tabs: const [
        Tab(
          icon: Text("INÍCIO"),
          //text: "Início",
        ),
        Tab(
          icon: Text("SERVIÇOS"),
        ),
        Tab(icon: Text("PORTFÓLIO")),
        //  Tab(icon: Text("SUPORTE")),
        Tab(icon: Text("SOBRE")),
      ],
    ),
  );
}
