import 'package:flutter/material.dart';

Widget buildFormField({required size, label, controller, width, large}) {
  return Container(
      child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(label,
          style: TextStyle(
              color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
      Container(
        width: size.width > 1000 ? size.width * 0.3 : size.width,
        margin: EdgeInsets.all(15),
        child: TextField(
            cursorColor: Colors.grey.shade600,
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white, fontSize: 18),
            maxLines: large != null ? large : 1,
            decoration: InputDecoration(
                fillColor: Colors.grey.shade800.withOpacity(0.4),
                filled: true,
                border: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white, width: 0.2),
                    borderRadius: BorderRadius.all(Radius.circular(8))),
                enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                        color: Colors.black.withOpacity(0), width: 0.5),
                    borderRadius: BorderRadius.all(Radius.circular(15))),
                focusedBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: Colors.white.withOpacity(0.4)),
                    borderRadius: BorderRadius.all(Radius.circular(15)))),
            controller: controller),
      )
    ],
  ));
}

Widget buildField({controller}) {
  return Container(
    width: 300,
    margin: EdgeInsets.all(15),
    height: 30,
    child: TextField(
        cursorColor: Colors.grey.shade600,
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.green, fontSize: 15),
        decoration: InputDecoration(
            border: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.white, width: 0.2),
                borderRadius: BorderRadius.all(Radius.circular(8))),
            enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.green, width: 0.5),
                borderRadius: BorderRadius.all(Radius.circular(15))),
            focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.white, width: 0.5),
                borderRadius: BorderRadius.all(Radius.circular(15)))),
        controller: controller),
  );
}
