import 'package:flutter/material.dart';
import 'package:olamundo/shared/themes/apptextstyles.dart';

Future aviso(context, {code}) async {
  return showDialog<void>(
    barrierColor: Colors.black.withOpacity(0.5),
    context: context,
    barrierDismissible: false, // user must tap button!
    builder: (BuildContext context) {
      return AlertDialog(
        backgroundColor: Colors.black,
        title: Text('Recurso em construção', style: Styles.textTitle),
        content: SingleChildScrollView(
          child: ListBody(
            children: <Widget>[
              Container(
                width: 300,
                child: Text(
                  'Ainda estamos trabalhando neste recurso.',
                  style: Styles.appText,
                ),
              ),
            ],
          ),
        ),
        actions: <Widget>[
          TextButton(
            child: const Text(
              'Fechar',
              style: TextStyle(color: Colors.white),
            ),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      );
    },
  );
}

Future mensagemEnviada(context) async {
  return showDialog<void>(
    barrierColor: Colors.black.withOpacity(0.5),
    context: context,
    barrierDismissible: false, // user must tap button!
    builder: (BuildContext context) {
      return AlertDialog(
        backgroundColor: Colors.black,
        content: SingleChildScrollView(
          child: ListBody(
            children: <Widget>[
              Text('Mensagem Enviada!', style: Styles.textTitle),
              Container(
                width: 300,
                child: Text(
                  'Sua mensagem foi enviada com sucesso. Entrarei em contato o mais breve possível para respondê-la.',
                  style: Styles.appText,
                ),
              ),
            ],
          ),
        ),
        actions: <Widget>[
          TextButton(
            child: const Text(
              'OK',
              style:
                  TextStyle(color: Colors.green, fontWeight: FontWeight.bold),
            ),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      );
    },
  );
}
