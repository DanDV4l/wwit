import 'package:flutter/material.dart';

class AppColors {
  static const appBar = Colors.black;
  static const logoMainTitle = Colors.white;
  static final logoAppStudio = Colors.green.shade400;
  static final tabBarSelected = Colors.green.shade500;
  static final tabBarUnselected = Colors.grey.shade300;
  static const textTitle = Colors.white;
  static const textColor = Colors.white;
  static final textboxBg = Colors.black.withOpacity(0.4);
}
