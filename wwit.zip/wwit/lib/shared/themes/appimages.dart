class AppImages {
  static final laptop = "assets/images/laptop.jpg";
  static final code = "assets/images/code.jpg";
  static final mobileDev = "assets/images/mobiledev.jpg";
  static final fix = "assets/images/fix.jpg";
  static final anydesk = "assets/images/anydesk.png";
  static final teamviewer = "assets/images/teamviewer.png";
  static final winassist = "assets/images/assistenciawindows.png";
  static final prototype = "assets/images/prototype.jpg";
  static final worldblur = "assets/images/world_blur.jpg";
  static final network = "assets/images/network.jpg";
  static final graphic = "assets/images/graphic.jpg";
  static final consult = "assets/images/consultory.jpg";
  static final manutencao = "assets/images/manutencao.jpg";
  static final flutter = "assets/images/flutterlogo.png";
  static final firebase = "assets/images/firebaselogo.png";
  static final api = "assets/images/api.png";
  static final aws = "assets/images/aws.png";
  static final photoshop = "assets/images/photoshop.png";
  static final github = "assets/images/github.png";
  static final linkedin = "assets/images/linkedin.png";
  static final whatsapp = "assets/images/whatsapp.png";
  static final card = "assets/images/card.jpg";
}
