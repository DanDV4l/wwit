import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:olamundo/modules/main/mainpage.dart';
import 'package:olamundo/shared/themes/appcolors.dart';

class Styles {
  static final mainTitle = GoogleFonts.megrim(
      fontSize: 30,
      color: AppColors.logoMainTitle,
      fontWeight: FontWeight.bold);
  static final mainTitleLarge = GoogleFonts.megrim(
      fontSize: 75,
      color: AppColors.logoMainTitle,
      fontWeight: FontWeight.bold);
  static final mainTitle2 = GoogleFonts.robotoMono(
    fontSize: 30,
    color: AppColors.logoMainTitle,
  );
  static final mainTitle2Large = GoogleFonts.robotoMono(
    fontSize: 75,
    color: AppColors.logoMainTitle,
  );
  static final textTitle = GoogleFonts.viga(
    fontSize: screenSize.width < 370 ? 22 : 25,
    color: AppColors.textTitle,
  );
  static final textTitle2 = GoogleFonts.viga(
      fontSize: screenSize.width < 370 ? 22 : 25,
      color: AppColors.textTitle,
      backgroundColor: Colors.black);
  static final textTitleBox = GoogleFonts.viga(
    fontSize: screenSize.width < 1000 ? 16 : 21,
    color: AppColors.textTitle,
  );
  static final buttonBox = GoogleFonts.viga(
    fontSize: screenSize.width < 600 ? 13 : 16,
    color: AppColors.textTitle,
  );
  static final textTitleInverse = GoogleFonts.viga(
    fontSize: 25,
    color: AppColors.appBar,
  );
  static final appStudio = GoogleFonts.viga(
    fontWeight: FontWeight.w100,
    fontSize: 15,
    color: AppColors.logoAppStudio,
  );
  static final appStudioLarge = GoogleFonts.viga(
    fontWeight: FontWeight.w100,
    fontSize: 45,
    color: AppColors.logoAppStudio,
  );
  static final appText = GoogleFonts.inter(
    fontSize: screenSize.width < 370 ? 12 : 15,
    color: AppColors.textColor,
  );
  static final tabBar = GoogleFonts.kanit(
      fontWeight: FontWeight.w900,
      fontSize: screenSize.width < 400 ? 11 : null);
  static final tabBarUnselected = GoogleFonts.kanit(
      color: Colors.white, fontSize: screenSize.width < 400 ? 11 : 16);
  static final tabBarSelected = GoogleFonts.kanit(
      color: Colors.green, fontSize: screenSize.width < 400 ? 11 : 16);
}
