package wwit.dev.wwitdev

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
