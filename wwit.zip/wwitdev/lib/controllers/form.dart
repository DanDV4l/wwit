import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

TextEditingController cName = TextEditingController();
TextEditingController cPhone = TextEditingController();
TextEditingController cEmail = TextEditingController();
TextEditingController cMessage = TextEditingController();

class Dados {
  FirebaseFirestore firestore = FirebaseFirestore.instance;

  CollectionReference chamados =
      FirebaseFirestore.instance.collection('chamadosPendentes');

  Future<void> addChamados() {
    var _hora = DateFormat.Hm().format(DateTime.now());
    var _data = DateFormat('dd/MM/y').format(DateTime.now());
    var _id = DateFormat('ddMMyHHmm').format(DateTime.now());

    return chamados.doc('$_id - ${cName.text}').set({
      "id": _id,
      "nome": cName.text,
      "telefone": cPhone.text,
      "email": cEmail.text,
      "mensagem": cMessage.text,
      "data": _data,
      "hora": _hora
    });
  }
}
