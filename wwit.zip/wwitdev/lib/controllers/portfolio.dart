import 'dart:convert';
import 'package:http/http.dart' as http;

class DataModel {
  String _nome;
  String _descricao;
  String _imgUrl;
  String _repositorio;

  get nome => _nome;
  get descricao => _descricao;
  get imgUrl => _imgUrl;
  get repositorio => _repositorio;

  set nome(var value) {
    _nome = value;
  }

  set descricao(var value) {
    _descricao = value;
  }

  set imgUrl(var value) {
    _imgUrl = value;
  }

  set repositorio(var value) {
    _repositorio = value;
  }

  DataModel(this._nome, this._descricao, this._imgUrl, this._repositorio);
}

Future<List<DataModel>> getPortfolio() async {
  List<DataModel> dataList = [];

  var _url = Uri.parse(
      'https://raw.githubusercontent.com/DanDV4l/apis/main/portfolio.json');
  var _response = await http.get(_url);
  var _data = jsonDecode(_response.body);
  for (var project in _data) {
    dataList.add(DataModel(project['nome'], project['descricao'],
        project['imgUrl'], project['repositorio']));
  }

  return dataList;
}
