import 'package:flutter/material.dart';
import 'package:wwitdev/shared/apptexts.dart';
import 'package:wwitdev/shared/objects/aboutbox.dart';
import 'package:wwitdev/shared/objects/buttons.dart';
import 'package:wwitdev/shared/objects/logo.dart';
import 'package:wwitdev/shared/themes/appimages.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:wwitdev/shared/themes/apptextstyles.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
        child: Container(
      margin: const EdgeInsets.only(top: 25),
      width: MediaQuery.of(context).size.width,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            child: Column(children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Column(
                    children: [
                      buildLogoLarge(),
                      Text(
                        "SOBRE",
                        style: Styles.textTitleBox,
                      ),
                      Container(
                        margin: const EdgeInsets.only(top: 25, bottom: 0),
                        width: 200,
                        height: 1,
                        color: Colors.white,
                      ),
                      buildAboutBox(
                        context,
                        text: AboutTexts.text1,
                      ),
                      Container(
                        margin: const EdgeInsets.only(top: 25, bottom: 45),
                        width: 200,
                        height: 1,
                        color: Colors.white.withOpacity(0),
                      ),
                    ],
                  ),
                ],
              ),
            ]),
          ),
          Wrap(
            children: [
              buildIconButton(
                  icon: AppImages.whatsapp,
                  label: "WhatsApp",
                  onTap: () {
                    launch('https://wa.me/5535988641641');
                  }),
              buildIconButton(
                  icon: AppImages.linkedin,
                  label: "LinkedIn",
                  onTap: () {
                    launch(
                        'https://www.linkedin.com/in/daniel-souza-pinto-40b0b4212');
                  }),
              buildIconButton(
                  icon: AppImages.github,
                  label: "Github",
                  onTap: () {
                    launch('https://github.com/DanDV4l');
                  }),
            ],
          ),
        ],
      ),
    ));
  }
}
