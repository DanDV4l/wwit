import 'package:flutter/material.dart';
import 'package:wwitdev/shared/apptexts.dart';
import 'package:wwitdev/shared/objects/buttons.dart';
import 'package:wwitdev/shared/objects/logo.dart';
import 'package:wwitdev/shared/themes/appimages.dart';
import 'package:wwitdev/shared/themes/apptextstyles.dart';
import 'package:url_launcher/url_launcher.dart';

class AboutPageMobile extends StatelessWidget {
  const AboutPageMobile({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
        physics: const BouncingScrollPhysics(
            parent: AlwaysScrollableScrollPhysics()),
        child: Container(
          margin: const EdgeInsets.all(15),
          width: MediaQuery.of(context).size.width,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              buildLogoLarge(),
              Container(
                margin: const EdgeInsets.all(25),
                width: 200,
                height: 1,
                color: Colors.white,
              ),
              Text(
                AboutTexts.title1,
                style: Styles.textTitle,
              ),
              SizedBox(
                  width: MediaQuery.of(context).size.width * 0.8,
                  child: Text(AboutTexts.text1, style: Styles.appText)),
              Container(
                margin: const EdgeInsets.only(top: 25, bottom: 45),
                width: 200,
                height: 1,
                color: Colors.white,
              ),

              Wrap(
                children: [
                  buildIconButton(
                      icon: AppImages.whatsapp,
                      label: "WhatsApp",
                      onTap: () {
                        launch('https://wa.me/5535988641641');
                      }),
                  buildIconButton(
                      icon: AppImages.linkedin,
                      label: "LinkedIn",
                      onTap: () {
                        launch(
                            'https://www.linkedin.com/in/daniel-souza-pinto-40b0b4212');
                      }),
                  buildIconButton(
                      icon: AppImages.github,
                      label: "Github",
                      onTap: () {
                        launch('https://github.com/DanDV4l');
                      }),
                ],
              ),

              //buildAboutTextBox(context)],
            ],
          ),
        ));
  }
}
