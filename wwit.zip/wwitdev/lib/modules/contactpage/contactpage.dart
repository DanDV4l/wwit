import 'package:flutter/material.dart';
import 'package:wwitdev/controllers/contact.dart';
import 'package:wwitdev/shared/objects/logo.dart';
import 'package:wwitdev/shared/objects/textfield.dart';
import 'package:wwitdev/shared/themes/apptextstyles.dart';

//botão enviar no módulo main

class ContactPage extends StatelessWidget {
  const ContactPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: ThemeData(
        scrollbarTheme: ScrollbarThemeData(
            isAlwaysShown: true,
            interactive: true,
            thumbColor:
                MaterialStateProperty.all(Colors.green.withOpacity(0.2))),
      ),
      child: Container(
          margin: const EdgeInsets.only(top: 25),
          padding: const EdgeInsets.only(bottom: 15),
          width: MediaQuery.of(context).size.width,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                buildLogoLarge(),
                Text('CONTATO', style: Styles.textTitleBox),
                Container(
                  margin: const EdgeInsets.only(top: 45),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.50,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Icon(Icons.drafts_outlined,
                                color: Colors.grey.withOpacity(0.7), size: 120),
                            const SizedBox(
                              width: 400,
                              child: Text(
                                "Precisa de mais informações, deseja deixar uma crítica ou gostaria de sugerir algo? \nEstá no lugar certo! Basta preencher os campos ao lado.",
                                style: TextStyle(
                                    fontSize: 20, color: Colors.white),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Column(
                        children: [
                          buildFormField(
                              size: MediaQuery.of(context).size,
                              label: "Seu nome: ",
                              controller: mNome),
                          buildFormField(
                              size: MediaQuery.of(context).size,
                              label: "Telefone/E-Mail: ",
                              controller: mContato),
                          buildFormField(
                              size: MediaQuery.of(context).size,
                              label: "Mensagem: ",
                              large: 6,
                              controller: mMensagem),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
          )),
    );
  }
}
