import 'package:flutter/material.dart';
import 'package:wwitdev/controllers/form.dart';
import 'package:wwitdev/shared/objects/buttons.dart';
import 'package:wwitdev/shared/objects/logo.dart';
import 'package:wwitdev/shared/objects/textfield.dart';
import 'package:wwitdev/shared/objects/warnings.dart';
import 'package:wwitdev/shared/themes/appimages.dart';
import 'package:wwitdev/shared/themes/apptextstyles.dart';

class FormPage extends StatefulWidget {
  const FormPage({Key? key}) : super(key: key);

  @override
  _FormPageState createState() => _FormPageState();
}

class _FormPageState extends State<FormPage> with TickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Theme(
        data: ThemeData(
            highlightColor: Colors.green,
            scrollbarTheme: ScrollbarThemeData(
                thumbColor:
                    MaterialStateProperty.all(Colors.green.withOpacity(0.2)))),
        child: Scaffold(
            appBar: PreferredSize(
              preferredSize:
                  Size.fromHeight(MediaQuery.of(context).size.height * 0.10),
              child: Container(
                color: Colors.black.withOpacity(0),
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * 0.1,
              ),
            ),
            backgroundColor: Colors.black,
            body: Scrollbar(
                isAlwaysShown: true,
                interactive: true,
                child: SingleChildScrollView(
                  child: Container(
                    width: size.width,
                    padding: const EdgeInsets.only(bottom: 200),
                    // height: size.height * 0.9,
                    decoration: const BoxDecoration(
                        image: DecorationImage(
                            image: AssetImage(AppImages.worldblur),
                            fit: BoxFit.cover)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            const VerticalDivider(),
                            Column(
                              children: [
                                buildLogoLarge(),
                                Text("SOLICITAR ATENDIMENTO",
                                    style: Styles.textTitle),
                                Container(
                                  margin: const EdgeInsets.only(
                                      top: 25, bottom: 50),
                                  width:
                                      MediaQuery.of(context).size.width * 0.25,
                                  child: const Text.rich(
                                    TextSpan(
                                        text: "AVISO: ",
                                        style: TextStyle(
                                            color: Colors.red,
                                            fontWeight: FontWeight.w900,
                                            fontSize: 23),
                                        children: [
                                          TextSpan(
                                              text:
                                                  " A disponibilidade do atendimento presencial pode variar de acordo com a sua localização.",
                                              style: TextStyle(
                                                  fontSize: 20,
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w100))
                                        ]),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              child: Column(
                                children: [
                                  buildFormField(
                                    controller: cName,
                                    size: size,
                                    label: "Seu nome: ",
                                  ),
                                  buildFormField(
                                    controller: cPhone,
                                    size: size,
                                    label: "Telefone para contato: ",
                                  ),
                                  buildFormField(
                                      controller: cEmail,
                                      size: size,
                                      label: "E-mail: "),
                                  buildFormField(
                                      controller: cMessage,
                                      size: size,
                                      label: "Como posso ajudar? ",
                                      large: 6),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      buildFormButton(
                                          icon: Icons.done_rounded,
                                          color: Colors.green,
                                          text: "SOLICITAR",
                                          onTap: () {
                                            Dados dados = Dados();

                                            dados.addChamados();
                                            cName.clear();
                                            cPhone.clear();
                                            cEmail.clear();
                                            cMessage.clear();

                                            Navigator.pop(context);
                                            solicitacaoEnviada(context);
                                          }),
                                      buildFormButton(
                                          icon: Icons.close,
                                          color: Colors.red,
                                          text: "CANCELAR",
                                          onTap: () {
                                            cName.clear();
                                            cPhone.clear();
                                            cEmail.clear();
                                            cMessage.clear();
                                            Navigator.pop(context);
                                          })
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ))));
  }
}
