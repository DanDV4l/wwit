// ignore_for_file: prefer_typing_uninitialized_variables

import 'package:flutter/material.dart';
import 'package:wwitdev/controllers/contact.dart';
import 'package:wwitdev/modules/about/aboutpage.dart';
import 'package:wwitdev/modules/about/aboutpagemobile.dart';
import 'package:wwitdev/modules/contactpage/contactpage.dart';
import 'package:wwitdev/modules/contactpage/contactpagemobile.dart';
import 'package:wwitdev/modules/home/homepage.dart';
import 'package:wwitdev/modules/home/homepagemobile.dart';
import 'package:wwitdev/modules/services/servicespage.dart';
import 'package:wwitdev/modules/services/servicespagemobile.dart';
import 'package:wwitdev/modules/portfolio/portfoliopage.dart';
import 'package:wwitdev/shared/objects/buttons.dart';
import 'package:wwitdev/shared/objects/warnings.dart';
import 'package:wwitdev/shared/objects/logo.dart';
import 'package:wwitdev/shared/themes/appimages.dart';
import 'package:wwitdev/shared/themes/apptextstyles.dart';

//captura tamanho da tela para repassar aos dimensionamento das fontes
var screenSize;

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  _MainPageState createState() => _MainPageState();
}

int i = 0;
GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

class _MainPageState extends State<MainPage> {
  @override
  Widget build(BuildContext context) {
    //captura dimensões da tela
    var _size = MediaQuery.of(context).size;
    screenSize = _size;

    Future.delayed(const Duration(milliseconds: 0), () {
      setState(() {
        contentVisible = true;
      });
    });

    state() {
      return setState(() {});
    }

    List<Widget> pages = [
      const HomePage(),
      const ServicesPage(),
      const PortfolioPage(),
      const ContactPage(),
      const AboutPage()
    ];

    List<Widget> pagesMobile = [
      const HomePageMobile(),
      const ServicesPageMobile(),
      const PortfolioPage(),
      const ContactPageMobile(),
      const AboutPageMobile()
    ];
    return Stack(
      children: [
        Container(
          color: Colors.black,
        ),
        Container(
          height: _size.height,
          width: _size.width,
          decoration: const BoxDecoration(
              image: DecorationImage(
                  image: AssetImage(AppImages.worldblur), fit: BoxFit.cover)),
        ),
        Scaffold(
          key: _scaffoldKey,
          floatingActionButton: i == 3
              ? FloatingActionButton(
                  child: const Icon(Icons.send, color: Colors.white, size: 30),
                  backgroundColor: Colors.grey.shade900.withOpacity(0.8),
                  foregroundColor: Colors.grey.withOpacity(0),
                  hoverColor: Colors.green,
                  splashColor: Colors.green,
                  onPressed: () {
                    Contato contato = Contato();
                    contato.sendMessage();
                    contato.clearFields();
                    mensagemEnviada(context);
                  })
              : null,
          drawerScrimColor: Colors.black.withOpacity(0.8),
          drawer: Container(
            height: MediaQuery.of(context).size.height,
            width: 250,
            padding: const EdgeInsets.only(top: 40),
            decoration: const BoxDecoration(
              color: Colors.black,
            ),
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics()),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  buildLogo(),
                  const Divider(),
                  buildMenuButton(
                      icon: Icons.home,
                      color: i != 0 ? Colors.white : Colors.green,
                      text: "Início",
                      onTap: () {
                        i = 0;

                        setState(() {});
                        Navigator.pop(context);
                      }),
                  buildMenuButton(
                      icon: Icons.home_repair_service_rounded,
                      color: i != 1 ? Colors.white : Colors.green,
                      text: "Serviços",
                      onTap: () {
                        i = 1;
                        setState(() {});
                        Navigator.pop(context);
                      }),
                  buildMenuButton(
                      icon: Icons.devices_other_rounded,
                      color: i != 2 ? Colors.white : Colors.green,
                      text: "Portfólio",
                      onTap: () {
                        i = 2;
                        setState(() {});
                        Navigator.pop(context);
                      }),
                  buildMenuButton(
                      icon: Icons.contact_mail_outlined,
                      color: i != 3 ? Colors.white : Colors.green,
                      text: "Contato",
                      onTap: () {
                        i = 3;
                        setState(() {});
                        Navigator.pop(context);
                      }),
                  buildMenuButton(
                      icon: Icons.person,
                      color: i != 4 ? Colors.white : Colors.green,
                      text: "Sobre",
                      onTap: () {
                        i = 4;
                        setState(() {});
                        Navigator.pop(context);
                      }),
                  const Divider(
                    color: Colors.grey,
                  ),
                  Text(
                    "Acesso rápido",
                    style: Styles.appText,
                  ),
                  buildMenuButton(
                    color: Colors.white,
                    icon: Icons.app_registration,
                    text: "Solicitar atendimento",
                    onTap: () {
                      Navigator.pushNamed(context, "/request");
                    },
                  ),
                  buildMenuButton(
                      color: Colors.grey,
                      icon: Icons.pending_actions_rounded,
                      text: "Andamento do serviço",
                      onTap: null),
                  /*  buildMenuButton(
                    color: Colors.grey,
                    icon: Icons.star_half_rounded,
                    text: "Clientes e parceiros",
                    onTap: () {
                      Navigator.pop(context);
                      aviso(context);
                    },
                  ),*/
                ],
              ),
            ),
          ),

          //cor de fundo padrão da aplicação
          backgroundColor: Colors.black.withOpacity(0),
          //início barra superior
          appBar: _size.width < 1120
              ? AppBar(
                  backgroundColor: Colors.black,
                  title: buildLogo(),
                  centerTitle: true,
                )
              : PreferredSize(
                  preferredSize: Size.fromHeight(
                      //Altura barra superior
                      _size.width > 1154 ? 150 : 50),
                  child: Container(
                      decoration: const BoxDecoration(
                        //Cor de fundo barra superior
                        color: Colors.black,
                      ),
                      //largura barra superior
                      width: MediaQuery.of(context).size.width,
                      //distanciamento interno da barra superior
                      padding: const EdgeInsets.only(right: 10, left: 10),
                      //altura interna da barra superior
                      height: _size.width > 1154 ? 45 : 50,
                      //conteúdo da barra superior
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              IconButton(
                                hoverColor: Colors.black.withOpacity(0),
                                focusColor: Colors.black.withOpacity(0),
                                splashColor: Colors.black.withOpacity(0),
                                highlightColor: Colors.black.withOpacity(0),
                                icon: Icon(Icons.menu_rounded,
                                    color: Colors.white.withOpacity(0.7),
                                    size: 20),
                                onPressed: () {
                                  _scaffoldKey.currentState?.openDrawer();
                                },
                              ),
                              //exibe abas na barra superior caso a largura da tela seja > 1154
                              _size.width > 1154
                                  ? Row(
                                      children: [
                                        Container(
                                          margin:
                                              const EdgeInsets.only(left: 20),
                                          child: TextButton(
                                              onPressed: () {
                                                i = 0;

                                                setState(() {});
                                              },
                                              child: Text(
                                                "INÍCIO",
                                                style: i != 0
                                                    ? Styles.tabBarUnselected
                                                    : Styles.tabBarSelected,
                                              )),
                                        ),
                                        Container(
                                          margin:
                                              const EdgeInsets.only(left: 20),
                                          child: TextButton(
                                              onPressed: () {
                                                i = 1;

                                                setState(() {});
                                              },
                                              child: Text(
                                                "SERVIÇOS",
                                                style: i != 1
                                                    ? Styles.tabBarUnselected
                                                    : Styles.tabBarSelected,
                                              )),
                                        ),
                                        Container(
                                          margin:
                                              const EdgeInsets.only(left: 20),
                                          child: TextButton(
                                              onPressed: () {
                                                i = 2;
                                                setState(() {});
                                              },
                                              child: Text(
                                                "PORTFÓLIO",
                                                style: i != 2
                                                    ? Styles.tabBarUnselected
                                                    : Styles.tabBarSelected,
                                              )),
                                        ),
                                        Container(
                                          margin:
                                              const EdgeInsets.only(left: 20),
                                          child: TextButton(
                                              onPressed: () {
                                                i = 3;
                                                setState(() {});
                                              },
                                              child: Text(
                                                "CONTATO",
                                                style: i != 3
                                                    ? Styles.tabBarUnselected
                                                    : Styles.tabBarSelected,
                                              )),
                                        ),
                                        Container(
                                          margin:
                                              const EdgeInsets.only(left: 20),
                                          child: TextButton(
                                              onPressed: () {
                                                i = 4;

                                                setState(() {});
                                              },
                                              child: Text(
                                                "SOBRE",
                                                style: i != 4
                                                    ? Styles.tabBarUnselected
                                                    : Styles.tabBarSelected,
                                              )),
                                        )
                                      ],
                                    )
                                  : Container(),
                              const VerticalDivider(),

                              //logo
                            ],
                          ),
                          buildLogo()
                        ],
                      )),
                ),
          //final barra superior

          body: _size.width >= 1150 ? pages[i] : pagesMobile[i],
        )
      ],
    );
  }
}
