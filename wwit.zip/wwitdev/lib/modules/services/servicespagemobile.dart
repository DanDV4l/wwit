import 'package:flutter/material.dart';

import 'package:wwitdev/shared/apptexts.dart';

import 'package:wwitdev/shared/objects/descriptionbox.dart';
import 'package:wwitdev/shared/objects/mobiletextbox.dart';

class ServicesPageMobile extends StatefulWidget {
  const ServicesPageMobile({Key? key}) : super(key: key);

  @override
  _ServicesPageMobileState createState() => _ServicesPageMobileState();
}

class _ServicesPageMobileState extends State<ServicesPageMobile> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics:
          const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
      child: Container(
        width: MediaQuery.of(context).size.width,
        margin: const EdgeInsets.all(10),
        child: Wrap(
          alignment: WrapAlignment.center,
          children: [
            SizedBox(
              width: 380,
              child: Column(
                children: [
                  buildMobileTextBox(
                      title: ServicesTexts.title1,
                      text: ServicesTexts.text1,
                      image: ServicesTexts.img1),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                          onPressed: () {
                            description(context, ServicesTexts.title1,
                                ServicesTexts.desc1);
                          },
                          child: const Text(
                            "Saiba mais",
                            style: TextStyle(
                                color: Colors.green,
                                fontWeight: FontWeight.bold),
                          )),
                      const VerticalDivider()
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              width: 380,
              child: Column(
                children: [
                  buildMobileTextBox(
                      title: ServicesTexts.title3,
                      text: ServicesTexts.text3,
                      image: ServicesTexts.img3),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                          onPressed: () {
                            description(context, ServicesTexts.title2,
                                ServicesTexts.desc3);
                          },
                          child: const Text(
                            "Saiba mais",
                            style: TextStyle(
                                color: Colors.green,
                                fontWeight: FontWeight.bold),
                          )),
                      const VerticalDivider()
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              width: 380,
              child: Column(
                children: [
                  buildMobileTextBox(
                      title: ServicesTexts.title2,
                      text: ServicesTexts.text2,
                      image: ServicesTexts.img2),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                          onPressed: () {
                            description(context, ServicesTexts.title3,
                                ServicesTexts.desc2);
                          },
                          child: const Text(
                            "Saiba mais",
                            style: TextStyle(
                                color: Colors.green,
                                fontWeight: FontWeight.bold),
                          )),
                      const VerticalDivider()
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              width: 380,
              child: Column(
                children: [
                  buildMobileTextBox(
                      title: ServicesTexts.title4,
                      text: ServicesTexts.text4,
                      image: ServicesTexts.img4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                          onPressed: () {
                            description(context, ServicesTexts.title4,
                                ServicesTexts.desc4);
                          },
                          child: const Text(
                            "Saiba mais",
                            style: TextStyle(
                                color: Colors.green,
                                fontWeight: FontWeight.bold),
                          )),
                      const VerticalDivider()
                    ],
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
