import 'package:flutter/material.dart';
import 'package:wwitdev/shared/objects/buttons.dart';
import 'package:wwitdev/shared/objects/descriptionbox.dart';
import 'package:wwitdev/shared/objects/logo.dart';
import 'package:wwitdev/shared/themes/appimages.dart';
import 'package:wwitdev/shared/themes/apptextstyles.dart';
// ignore: avoid_web_libraries_in_flutter
import 'dart:html' as html;

class SupportPage extends StatelessWidget {
  const SupportPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    ScrollController _scrollSupport = ScrollController();
    return Theme(
        data: ThemeData(
            // highlightColor: Colors.green,
            scrollbarTheme: ScrollbarThemeData(
                thumbColor:
                    MaterialStateProperty.all(Colors.green.withOpacity(0.2)))),
        child: Scrollbar(
            controller: _scrollSupport,
            isAlwaysShown: true,
            interactive: true,
            child: SingleChildScrollView(
              controller: _scrollSupport,
              child: Container(
                padding: const EdgeInsets.only(top: 25),
                width: MediaQuery.of(context).size.width,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    buildLogoLarge(),
                    Text(
                      'SUPORTE',
                      style: Styles.textTitle,
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 20, bottom: 20),
                      width: MediaQuery.of(context).size.width * 0.40,
                      child: Text(
                          'Os softwares listados abaixo são essenciais para que possamos prosseguir com o atendimento remoto. Faça o download dos softwares que foram solicitados para o atendimento e aguarde instruções.',
                          style: Styles.appText),
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 25, bottom: 25),
                      width: 200,
                      height: 1,
                      color: Colors.white.withOpacity(0),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.70,
                      padding: const EdgeInsets.all(20),
                      margin: const EdgeInsets.only(bottom: 40),
                      decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.2),
                          borderRadius:
                              const BorderRadius.all(Radius.circular(15))),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              buildVerticalIconButton(
                                  icon: AppImages.winassist,
                                  label: "Asstência rápida\ndo Windows",
                                  onTap: () {
                                    description(
                                        context,
                                        "Assistência rápida do Windows",
                                        "Disponível apenas para Windows. Se você usa Windows 10 ou superior, você pode digitar \"Assistência rápida\" na busca do Windows e não será necessário instalar nenhum outro software e será necessário apenas que siga nossas intruções.");
                                  }),
                              buildVerticalIconButton(
                                  icon: AppImages.anydesk,
                                  label: "Anydesk",
                                  onTap: () {
                                    html.window.open(
                                        'https://anydesk.com/pt/downloads/',
                                        '');
                                  }),
                              buildVerticalIconButton(
                                  icon: AppImages.teamviewer,
                                  label: "Teamviewer",
                                  onTap: () {
                                    html.window.open(
                                        'https://www.teamviewer.com/', '');
                                  }),
                            ],
                          ),
                          Container(
                            height: 250,
                            width: 0.5,
                            color: Colors.white,
                            margin: const EdgeInsets.fromLTRB(35, 10, 35, 10),
                          ),
                          Column(
                            children: [
                              Text("Softwares de assistência remota.",
                                  style: Styles.textTitle),
                              SizedBox(
                                width: MediaQuery.of(context).size.width * 0.35,
                                child: Text(
                                    "São softwares que possibilitam o acesso e controle do computador remotamente, isto é, vai ser como se o técnico estivesse presencialmente mexendo no seu computador tentando encontrar e solucionar o problema em alguma configuração ou qualquer problema relacionado ao software.",
                                    style: Styles.appText),
                              ),
                            ],
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            )));
  }
}
