import 'package:wwitdev/shared/themes/appimages.dart';

class AppTexts {
  //caixa 1
  static const String title1 = "Tire suas ideias do papel";
  static const String text1 =
      "Com o avanço da tecnologia, hoje os negócios também se estendem para o mundo virtual. Que tal colocar em prática suas ideias? Com um site e/ou aplicativo, você tem a garantia de que seu produto ou serviço chegará a um público consideravelmente maior. Ou também, caso você precise apenas otimizar ou automatizar um processo em seu negócio, também podemos te ajudar a atingir seus objetivos!";
  static const img1 = AppImages.laptop;
  static const link1 = "";

  //caixa3
  static const String title2 = "Um aplicativo móvel ou um site";
  static const String text2 =
      "Precisa inovar na forma de vender seus produtos ou oferecer seus serviços? Que tal trabalharmos juntos? Vamos bater um papo, criar um protótipo de sua ideia e testarmos juntos para saber o que funciona e o que precisa ser melhorado.";
  static const img2 = AppImages.mobileDev;
  static const link2 = "";

  //caixa2

  static const String title3 = "Já conhece o Flutter?";
  static const String text3 =
      "O Flutter é uma tecnologia criada pelo Google que possibilita a criação de aplicativos para dispositivos móveis, PC (Windows/Mac/Linux) e web. É a tecnologia base de nossas aplicações e grandes empresas como BMW, Nubank, Tencent, Alibaba Group, eBay e muitas outras também já utilizam o Flutter, que tem o Dart como sua linguagem base.";
  static const String img3 = AppImages.code;
  static const link3 = "";

  //caixa4
  static const String title4 = "Um cartão de visitas diferenciado";
  static const String text4 =
      "Às vezes a primeira impressão é a que fica, então, que tal um cartão de visitas diferenciado? Você pode ter um cartão de visitas que contenha suas informações profissionais e mais, você pode ter um QR Code que direcione seus clientes a seu site e/ou às suas redes sociais. \n Caso não tenha um site ainda, que tal ter o seu próprio site personalizado?";
  static const img4 = AppImages.card;
  static const link4 = "";

  //caixa5
  static const String title5 = "Problemas na sua casa ou empresa?";
  static const String text5 =
      "Se você precisa de assistência técnica, aqui também é o lugar certo. Um computador com problemas pode prejucar o seu tempo de lazer ou até mesmo sua produtividade no trabalho/estudo e o problema pode ser mais simples do que você imagina. Solicite um atendimento e vamos juntos solucionar o problema!";
  static const img5 = AppImages.fix;
  static const link5 = "";
}

class ServicesTexts {
  //box 1
  static const String title1 = "Desenvolvimento de Software";
  static const String text1 =
      "O mundo mudou e com o avanço da tecnologia, hoje os negócios também se estendem para o mundo virtual. Que tal colocar em prática suas ideias? Com um site e/ou aplicativo, você tem a garantia de que seu produto ou serviço chegará a um público consideravelmente maior. Ou também caso você precise apenas otimizar ou automatizar um processo em seu negócio, também podemos te ajudar a atingir seus objetivos!";
  static const String desc1 =
      "- Aplicativos para Android\n- Aplicativos para iOS\n- Aplicativos para Windows\n- Aplicativos para Linux\n- Aplicativos para Mac\n- Páginas Web";
  static const String img1 = AppImages.mobileDev;
  //box2
  static const String title2 = "Consultoria em TI";
  static const String text2 =
      "Precisa de ajuda na gestão de sua infraestrutura de TI? Vamos juntos identificar as necessidades da sua empresa, elaborar um programa de trabalho personalizado e construir uma solução.";
  static const String desc2 =
      "- Implantação de tecnologia\n- Upgrade de Hardware/Software\n- Planejamento de infraestrutura de rede\n- Aconselhamento de soluções em TI";
  static const String img2 = AppImages.consult;

  //box3
  static const String title3 = "Suporte Técnico";
  static const String text3 =
      "Não tem jeito! Computadores lentos ou que travam com frequência podem prejudicar o seu desempenho profissional ou estragar o seu momento de lazer. Às vezes a solução pode ser mais simples do que você imagina.";
  static const String desc3 =
      "- Atendimento remoto\n- Atendimento presencial (dependendo da sua localidade)\n- Otimização de sistema\n- Montagem e manutenção de computadores\n- Formatação (Mac e PC)\n- instalação de softwares\n- Remoção de malwares\n- Configuração e compartilhamento de impressoras na rede\n- Configuração de redes\n- Configuração de roteadores\n- Backups";
  static const String img3 = AppImages.manutencao;
  //box4
  static const String title4 = "Artes Visuais";
  static const String text4 =
      "Proporcione uma identidade visual à sua marca, faça um cartão de visita personalizado de acordo com sua necessidade. A identidade visual tem forte apelo diante do público e demonstra como você e/ou a sua marca pretende atingir o mercado.";
  static const String desc4 =
      "- Edição e restauração de fotografias\n- Cartões de visita (impresso e virtual)\n- Logotipos\n- Convites\n- Panfletos\n- Folders\n- Desenhos vetoriais";
  static const String img4 = AppImages.graphic;
}

class AboutTexts {
  static const String image1 = AppImages.consult;
  static const String title1 = "SOBRE";
  static const String text1 =
      "Meu nome é Daniel Souza Pinto, criei o site Ww:IT.dev com o intuito de demonstrar minhas habilidades com o Flutter, facilitar o gerenciamento de meus serviços e aumentar o meu alcance como profissional. Trabalho na área de TI há aproximadamente 14 anos. Há pouco mais de 3 anos estudo para adquirir proficiência no desenvolvimento de aplicações para dispositivos móveis, desktop e web, utilizando o Flutter. Também possuo habilidades com as ferramentas de edição de imagens da Adobe, o Photoshop e o Illustrator. ";
}
