import 'package:flutter/material.dart';

import 'package:wwitdev/shared/themes/apptextstyles.dart';

Widget buildAboutBox(
  context, {
  text,
}) {
  return Container(
    width: MediaQuery.of(context).size.width * 0.60,
    margin: const EdgeInsets.only(top: 15),
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
        color: Colors.black.withOpacity(0),
        borderRadius: const BorderRadius.all(Radius.circular(8))),
    //height: 250,
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(
          width: MediaQuery.of(context).size.width * 0.55,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                text,
                style: Styles.appText,
                textAlign: TextAlign.justify,
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

Widget buildAboutBoxInverse(
  context, {
  image,
  title,
  text,
}) {
  return Container(
    width: MediaQuery.of(context).size.width * 0.60,
    margin: const EdgeInsets.only(top: 15),
    decoration: BoxDecoration(
        color: Colors.grey.shade800.withOpacity(0),
        border: Border.all(color: Colors.white.withOpacity(0), width: 0),
        borderRadius: const BorderRadius.all(Radius.circular(20))),
    //height: 250,
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          width: MediaQuery.of(context).size.width * 0.35,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                title,
                style: Styles.textTitle,
              ),
              Text(
                text,
                style: Styles.appText,
                textAlign: TextAlign.justify,
              ),
            ],
          ),
        ),
        Container(
          height: 250,
          decoration: BoxDecoration(
              image:
                  DecorationImage(image: AssetImage(image), fit: BoxFit.cover),
              borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(70),
                  topRight: Radius.circular(70))),
          width: 250,
        ),
        const VerticalDivider(),
      ],
    ),
  );
}
