import 'package:flutter/material.dart';
import 'package:wwitdev/shared/objects/buttons.dart';
import 'package:wwitdev/shared/themes/appcolors.dart';
import 'package:wwitdev/shared/themes/appimages.dart';
import 'package:wwitdev/shared/themes/apptextstyles.dart';

Widget buildLargerTextBox(context, {title, description, image, onTap}) {
  //var size = MediaQuery.of(context).size;
  return Container(
    padding: const EdgeInsets.all(5),
    margin: const EdgeInsets.all(5),
    width: 400,
    decoration: BoxDecoration(
        color: AppColors.textboxBg,
        //  border: Border.all(color: AppColors.textColor.withOpacity(0.4)),
        borderRadius: const BorderRadius.all(Radius.circular(15))),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          width: 390,
          height: 290,
          decoration: const BoxDecoration(
              image: DecorationImage(
                  image: AssetImage(
                    AppImages.mobileDev,
                  ),
                  fit: BoxFit.cover),
              borderRadius: BorderRadius.all(Radius.circular(15))),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
              child: Text(
                "TÍTULO",
                style: Styles.textTitleBox,
                textAlign: TextAlign.start,
              ),
            ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
          child: Text(
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
            style: Styles.appText,
            textAlign: TextAlign.start,
          ),
        ),
        onTap != null
            ? Container(
                width: 100,
                height: 1,
                color: Colors.white,
              )
            : const SizedBox(),
        onTap != null
            ? SizedBox(
                width: 200,
                child: buildMenuButton(
                  onTap: onTap,
                  icon: Icons.architecture_rounded,
                  text: "LINK DO PROJETO",
                  color: AppColors.tabBarSelected,
                ),
              )
            : const SizedBox()
      ],
    ),
  );
}
