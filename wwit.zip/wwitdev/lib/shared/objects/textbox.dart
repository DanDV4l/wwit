import 'package:flutter/material.dart';
import 'package:wwitdev/shared/objects/descriptionbox.dart';
import 'package:wwitdev/shared/themes/appcolors.dart';
import 'package:wwitdev/shared/themes/apptextstyles.dart';

Widget buildContentHorizontal(BuildContext context, {image, title, text}) {
  var _size = MediaQuery.of(context).size;
  return Row(
    mainAxisAlignment: MainAxisAlignment.center,
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(
        margin: const EdgeInsets.only(bottom: 10, top: 10),
        width: _size.width * 0.30,
        height: _size.height * 0.45,
        decoration: BoxDecoration(
          // border: Border.all(width: 0),
          image: DecorationImage(image: AssetImage(image), fit: BoxFit.fill),
          borderRadius: const BorderRadius.only(
              bottomLeft: Radius.circular(200), topLeft: Radius.circular(0)),
        ),
      ),
      Container(
        margin: const EdgeInsets.only(bottom: 10, top: 10),
        decoration: BoxDecoration(
            color: AppColors.textboxBg,
            //  border: Border.all(width: 0),
            borderRadius: const BorderRadius.only(
                topRight: Radius.circular(200),
                bottomRight: Radius.circular(0))),
        padding: const EdgeInsets.all(20),
        width: _size.width * 0.4,
        height: _size.height * 0.45,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SelectableText(
              title,
              style: Styles.textTitle,
            ),
            SizedBox(
              width: _size.width * 0.30,
              height: _size.height * 0.22,
              child: SelectableText(
                text,
                maxLines: 25,
                textAlign: TextAlign.start,
                style: Styles.appText,
                textScaleFactor: 1,
              ),
            ),
          ],
        ),
      ),
    ],
  );
}

Widget buildContentHorizontalInverse(BuildContext context,
    {image, title, text, link}) {
  var _size = MediaQuery.of(context).size;
  return Row(
    mainAxisAlignment: MainAxisAlignment.center,
    crossAxisAlignment: CrossAxisAlignment.end,
    children: [
      Container(
        decoration: BoxDecoration(
            color: AppColors.textboxBg,
            //      border: Border.all(width: 0),
            borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(200), bottomLeft: Radius.circular(0))),
        padding: const EdgeInsets.all(20),
        width: _size.width * 0.4,
        height: _size.height * 0.45,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SelectableText(
              title,
              style: Styles.textTitle,
            ),
            SizedBox(
              width: _size.width * 0.30,
              height: _size.height * 0.22,
              child: SelectableText(
                text,
                maxLines: 25,
                textAlign: TextAlign.end,
                style: Styles.appText,
                textScaleFactor: 1,
              ),
            ),
          ],
        ),
      ),
      Container(
        width: _size.width * 0.30,
        height: _size.height * 0.45,
        decoration: BoxDecoration(
          //    border: Border.all(width: 0.2),
          image: DecorationImage(image: AssetImage(image), fit: BoxFit.fill),
          borderRadius: const BorderRadius.only(
              bottomLeft: Radius.circular(0),
              bottomRight: Radius.circular(200)),
        ),
      ),
    ],
  );
}

Widget buildContentIconHorizontal(BuildContext context,
    {image, title, items, link}) {
  var _size = MediaQuery.of(context).size;
  return Row(
    mainAxisAlignment: MainAxisAlignment.center,
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      Container(
        margin: const EdgeInsets.only(bottom: 10, top: 10),
        width: _size.width * 0.30,
        height: _size.height * 0.45,
        decoration: BoxDecoration(
          border: Border.all(width: 0.2),
          image: DecorationImage(image: AssetImage(image), fit: BoxFit.fill),
          borderRadius: const BorderRadius.only(
              bottomLeft: Radius.circular(200), topLeft: Radius.circular(0)),
        ),
      ),
      Container(
        margin: const EdgeInsets.only(bottom: 10, top: 10),
        decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            border: Border.all(width: 0.2),
            borderRadius: const BorderRadius.only(
                topRight: Radius.circular(200),
                bottomRight: Radius.circular(0))),
        padding: const EdgeInsets.all(20),
        width: _size.width * 0.5,
        height: _size.height * 0.45,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SelectableText(
              title,
              style: Styles.textTitle,
            ),
            SizedBox(
              width: _size.width * 0.45,
              //height: _size.height * 0.20,
              child: Wrap(
                children: items,
              ),
            ),
          ],
        ),
      ),
    ],
  );
}

Widget buildContentIconHorizontalInverse(BuildContext context,
    {image, title, items, link}) {
  var _size = MediaQuery.of(context).size;
  return Row(
    mainAxisAlignment: MainAxisAlignment.center,
    crossAxisAlignment: CrossAxisAlignment.end,
    children: [
      Container(
        decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            border: Border.all(width: 0.2),
            borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(200), bottomLeft: Radius.circular(0))),
        padding: const EdgeInsets.all(20),
        width: _size.width * 0.50,
        height: _size.height * 0.45,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SelectableText(
              title,
              style: Styles.textTitle,
            ),
            Wrap(
              children: items,
            )
          ],
        ),
      ),
      Container(
        width: _size.width * 0.30,
        height: _size.height * 0.45,
        decoration: BoxDecoration(
          border: Border.all(width: 0.2),
          image: DecorationImage(image: AssetImage(image), fit: BoxFit.fill),
          borderRadius: const BorderRadius.only(
              bottomLeft: Radius.circular(0),
              bottomRight: Radius.circular(200)),
        ),
      ),
    ],
  );
}

Widget buildServiceBox(
  context, {
  image,
  title,
  text,
  desc,
}) {
  return Container(
    width: MediaQuery.of(context).size.width * 0.60,
    margin: const EdgeInsets.only(top: 15),
    decoration: BoxDecoration(
        color: Colors.grey.shade800.withOpacity(0),
        border: Border.all(color: Colors.white.withOpacity(0), width: 0),
        borderRadius: const BorderRadius.all(Radius.circular(20))),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(
          height: 250,
          decoration: BoxDecoration(
              image:
                  DecorationImage(image: AssetImage(image), fit: BoxFit.cover),
              borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(70),
                  topRight: Radius.circular(70))),
          width: 250,
        ),
        SizedBox(
          width: MediaQuery.of(context).size.width * 0.35,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                title,
                style: Styles.textTitle,
              ),
              Text(
                text,
                style: Styles.appText,
                textAlign: TextAlign.justify,
              ),
              TextButton(
                child: const Text(
                  "Saiba mais",
                  style: TextStyle(color: Colors.green),
                ),
                onPressed: () {
                  description(context, title, desc);
                },
              )
            ],
          ),
        ),
        const VerticalDivider()
      ],
    ),
  );
}

Widget buildServiceBoxInverse(
  context, {
  image,
  title,
  text,
  desc,
}) {
  return Container(
    width: MediaQuery.of(context).size.width * 0.60,
    margin: const EdgeInsets.only(top: 15),
    decoration: BoxDecoration(
        color: Colors.grey.shade800.withOpacity(0),
        border: Border.all(color: Colors.white.withOpacity(0), width: 0),
        borderRadius: const BorderRadius.all(Radius.circular(20))),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          width: MediaQuery.of(context).size.width * 0.35,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                title,
                style: Styles.textTitle,
              ),
              Text(
                text,
                style: Styles.appText,
                textAlign: TextAlign.justify,
              ),
              TextButton(
                child: const Text(
                  "Saiba mais",
                  style: TextStyle(color: Colors.green),
                ),
                onPressed: () {
                  description(context, title, desc);
                },
              )
            ],
          ),
        ),
        Container(
          height: 250,
          decoration: BoxDecoration(
              image:
                  DecorationImage(image: AssetImage(image), fit: BoxFit.cover),
              borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(70),
                  topRight: Radius.circular(70))),
          width: 250,
        ),
        const VerticalDivider(),
      ],
    ),
  );
}
