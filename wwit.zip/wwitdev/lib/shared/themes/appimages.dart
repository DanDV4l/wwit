class AppImages {
  static const laptop = "assets/images/laptop.jpg";
  static const code = "assets/images/code.jpg";
  static const mobileDev = "assets/images/mobiledev.jpg";
  static const fix = "assets/images/fix.jpg";
  static const anydesk = "assets/images/anydesk.png";
  static const teamviewer = "assets/images/teamviewer.png";
  static const winassist = "assets/images/assistenciawindows.png";
  static const prototype = "assets/images/prototype.jpg";
  static const worldblur = "assets/images/world_blur.jpg";
  static const network = "assets/images/network.jpg";
  static const graphic = "assets/images/graphic.jpg";
  static const consult = "assets/images/consultory.jpg";
  static const manutencao = "assets/images/manutencao.jpg";
  static const flutter = "assets/images/flutterlogo.png";
  static const firebase = "assets/images/firebaselogo.png";
  static const api = "assets/images/api.png";
  static const aws = "assets/images/aws.png";
  static const photoshop = "assets/images/photoshop.png";
  static const github = "assets/images/github.png";
  static const linkedin = "assets/images/linkedin.png";
  static const whatsapp = "assets/images/whatsapp.png";
  static const card = "assets/images/card.jpg";
}
